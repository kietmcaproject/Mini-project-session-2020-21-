<style>
    table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td,
        th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
            
        }
        th{
            background-color: blueviolet;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
        tr td:hover
        {
            background:hotpink;
            border-radius: 5px;
            border-color: aquamarine;
        }
        
        a:link{
            text-decoration: none;
            text-decoration-style: dashed;
        }
</style>
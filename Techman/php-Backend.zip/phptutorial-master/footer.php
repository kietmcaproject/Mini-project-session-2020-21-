<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer 
{
   position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   border-radius: 15px;
   background-color: blueviolet;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
<div class="footer">
	<p>Copyright © 2019 Kiet Group Of Institutions. All Rights Reserved.</p>
</div>

</body>
</html> 
	
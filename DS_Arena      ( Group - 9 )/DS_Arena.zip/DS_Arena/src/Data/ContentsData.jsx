const ContentsData = [
    {
        Link:"https://i2.wp.com/blog.contactsunny.com/wp-content/uploads/2019/12/photo-1559944554-fb295d391db7.jpeg?resize=1400%2C850&ssl=1",
        Title:"Linked List" ,
        Description:"Explore Linked List"
    }
    ,{
        Link : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGs7WcpE7uU3uGBeA_Fb1_zrNL65lda_-H-Q&usqp=CAU" ,
       Title: "Stack" ,
       Description :"Explore Stack" 

    } ,
    {
        Link: "https://koenig-media.raywenderlich.com/uploads/2017/06/HeapPriorityQueue-feature.png" , 
        Title:"Queue",
        Description :"Explore Queue"

    },
    {
        Link:"https://neverstopcodingblog.files.wordpress.com/2017/07/tree.jpg?w=450&h=300&crop=1",
        Title:"Binary Search Tree" ,
        Description:"Explore Binary Search Tree"
    },
]
export default ContentsData ; 
/* https://miro.medium.com/max/1400/1*waoJAf5XZnY6EdlUSO2QIA.peg"  */
/* https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQ6WjX462b4WCg09kjevqIsjUXJIyo9zWmjw&usqp=CAU */
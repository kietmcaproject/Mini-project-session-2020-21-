import React from "react" ;
import NavBar from "./StackNavBar" ;
const Peek = ()=>{
    const url = "https://miro.medium.com/max/790/1*1okwhewf5KCtIPaFib4XaA.gif";

    const elem = <>
    <NavBar/>
    <div className="StackContainer">
        <h1><center><i>Peek Operation</i> </center> </h1>
        </div>

        <div className="StackContainer">
        <h2><b><center>STACK OPERATION (POP) ARE PERFORMED</center></b></h2>
        </div>
        <div className="imgclass">
        <img className="arimg" src= {url}alt="al"></img>
        </div>  
    </>
    return elem ; 
} 
export default Peek ; 
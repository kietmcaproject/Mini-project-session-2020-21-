import Nav from "./StackNavBar";
const CompleteProgram = () => {
    const elem = <>
        <Nav />
        <div className="StackContainer">
        <h1>CompleteProgram </h1>
        </div>

        <div className="StackContainer">
        <h1><b><marquee>Please Add a Acknowledgement - Quiz</marquee></b></h1>
        </div>

        
       
        


        const Footer = () 
  <div className="footer">
    <p><center>THIS IS A FOOTER - SECTION </center></p>
  </div>

    </>
    return elem;
}
export default CompleteProgram;
import React from "react" ;
import SNavBar from "./StackNavBar" ;
import Data from "./StackData/Data.json";
import "./Stack.css";
import Img from "./Stack_Images/Stack_Array_Push.png" ;
import Img2 from "./Stack_Images/Stack_Linked_Push.png" ;



function NewlineText(props) {
    const text = props.text;
    return text.split('\n').map(str => <p>{str}</p>);
  }


const Push = ()=>{
    const url = "https://gochronicles.com/content/images/2021/05/Stack1.gif";
    
    const elem = <>
    <SNavBar/>
    <h2 className="StackContainer" >
         {Data[5].content} 
    </h2>
    <div className="About">
    <NewlineText text = {Data[5].data} />  
    <br/> 
    <img className="Img" src= {url}alt="al"></img>
    </div><br/>
    <h2 className="StackContainer">
       <NewlineText text= {Data[5].content2} />
    </h2>
    <br/>
    <div className="About" >
    <NewlineText text = {Data[5].content5}/>
    <br/>
    <img src= {Img} className="Cont_Img" alt="array_pussh"/>
   </div>
   <br/>
   <h2 className="StackContainer">
   <NewlineText text=  {Data[5].content4} />
   </h2>
   <br/>
   <div className="About">
   <NewlineText text = {Data[5].content3} />
   <br/>
   <img src={Img2} className="Cont_Img" alt="push" />
   </div>


    </>
    return elem ; 
} 
export default Push ; 
import React from "react" ;
import NavBar from "./StackNavBar" ;
import Data from "./StackData/Data.json";
import "./Stack.css";

function NewlineText(props) {
    const text = props.text;
    return text.split('\n').map(str => <p>{str}</p>);
  }


const Pop = ()=>{
    const url = "https://gochronicles.com/content/images/2021/05/Stack2.gif";

    const elem = <>
    <NavBar/>
    <div className="StackContainer">
        <h2> <i> {Data[6].content}</i> </h2>
        </div>

    <div className="About">
    <br/> 
    <NewlineText text = {Data[6].data} />
    <br/>
    <img className="Img" src= {url}alt="al"></img>
    </div> 
    <br/>
    <br/>

    <div className ="About">
    <br/>

    <br/>
    </div>
    <br/>
    <div className ="About">
    <br/>
    
    <br/>
    </div>


    </> 
    return elem ; 
} 
export default Pop ; 
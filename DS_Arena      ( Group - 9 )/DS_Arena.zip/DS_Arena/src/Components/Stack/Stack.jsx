import React from "react";
import "./Stack.css";
import StackNavBar from "./StackNavBar";
import Data from "./StackData/Data.json";

const url = "https://prmoreira23.github.io/assets/stack-data-structure.gif";

function NewlineText(props) {
    const text = props.text;
    return text.split('\n').map(str => <p>{str}</p>);
  }
const Stack = () => {
    const elem = <>
        <StackNavBar/>
        <h2 className="StackContainer" >
         <NewlineText text = {Data[0].content} /> 

        </h2>
        <p className = "About">

        {Data[0].about}
        <br/>
        <br/> 
        <NewlineText text = {Data[0].data} /> 
        <br/>
        <img src ={url} className= "Img" alt="getImage" >
        </img>
        <br/>
        <br/>
        {Data[1].content}
        <br/>
        <br/>
        <NewlineText text = {Data[1].data}/>
        <br/>
        <br/>
        {Data[2].content}
        <br/>
        <br/>
        <NewlineText text = {Data[2].data}/>

           
        </p>
        </>
        

        return elem;
}
        export default Stack;
import Nav from "./StackNavBar";
import "./Stack.css";
import Data from "./StackData/Data.json";
import Img1 from "./Stack_Images/Array_Representation.png" ;

function NewlineText(props) {
    const text = props.text;
    return text.split('\n').map(str => <p>{str}</p>);
  }

const ArrayRepresentation = () => {
        const elem = <>
        <Nav />
        <br/>
        <h2 className="StackContainer" >
         <NewlineText text = {Data[3].content} /> 

        </h2>
        <p className="About">
        {Data[3].data}
        <br/>
        <br/>
        <NewlineText text = { Data[3].data2 } />
        <br/>
        <br/>
        <NewlineText text = {Data[3].data4}/>
        <br/>
        <NewlineText text = {Data[3].data3}/>
        <br/>
        
        <img src={ Img1 } className="Cont_Img" alt="Array_Representstion"/>
        <br/>
        <br/>
        <NewlineText text = {Data[3].content2}/>
        <br/>
        <NewlineText text = {Data[3].data5}/>
        </p>
        </>
        return elem ; 
}
export default ArrayRepresentation ;

        
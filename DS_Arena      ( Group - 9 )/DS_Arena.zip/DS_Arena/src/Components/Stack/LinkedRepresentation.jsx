import Nav from "./StackNavBar";
import Img from "./Stack_Images/Linked_Representation.png"; 
import "./Stack.css";
import Data from "./StackData/Data.json"; 
const LinkedRepresentation = () => {
    
        const elem = <>
        <Nav />
        <h2 className="StackContainer">
        {Data[4].content}
        </h2>
        <p className="About">
        <img src={Img} className="Cont_Img" alt="Linked_Representation"/>
        </p>
        
        const Footer = () 
 
    </>
    return elem;
}
export default LinkedRepresentation;

/*
  <div className="footer">
  <p><center>This is some content in sticky footer</center></p>
  </div>
*/
<?
@extract($_SESSION);
if(is_array($_SESSION['arr_error_msgs']) && count($_SESSION['arr_error_msgs'])>0) {?>

<div class="error warning" style="color:#a05b06;   border-radius:5px; padding-left:20px;"> 


<? foreach($_SESSION['arr_error_msgs'] as $err_msg){?>
 <?=$err_msg?><br />

<? }?>
 
</div> 


<? } $_SESSION['arr_error_msgs']=''; ?>
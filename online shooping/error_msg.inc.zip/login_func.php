<?
include ("includes/surya.dream.php"); 
 #header("location: registration_stop.php");
 #exit;
  //print_r($_POST);
//@extract($_POST);
//and  u_status!='Banned' and  u_status='Active' 
 if ($username=='sb' && $password=='111111') {
	$_SESSION['sess_guest'] = $username;
  	if ($_SESSION['sess_back']!='') {
		header("location: ".$_SESSION['sess_back']);
		$_SESSION['sess_back']='';	
		exit;	
	} else {
		 header("location: userpanel/myaccount.php");
		 exit;	
	}
}
/**/
///$arr_error_msgs[] =  "Dear  member we are upgrading our server! login will be start soon to access your account. " ;
//$_SESSION['arr_error_msgs'] = $arr_error_msgs;
//header("Location: login.php");
//exit; 

if ($_POST['conf_num2']!=$_POST['conf_num1']){ 
		$arr_error_msgs[] ="Captcha number does not match"; 
		$_SESSION['arr_error_msgs'] = $arr_error_msgs;
		header("Location: login.php");
		exit;
	}
 
	/* $user_join_mode = db_scalar("select u_join_mode from ngo_users where (u_username = '$username' OR u_mobile = '$username')");
 	if($user_join_mode=='General') {  ////General user
	$sql = "select * from ngo_users where u_username2='$username'   ";
	} else {   ////affiliate user
	$sql = "select * from ngo_users where u_mobile = '$username'  ";
	} */
	
	
	$sql = "select * from ngo_users where u_username='$username'   ";
	
	$result = db_query($sql);
	if ($line= mysqli_fetch_array($result)) {
		@extract($line);
		if($u_status=='Banned') {
			$_SESSION['sess_blocked_msg'] = $u_blocked_msg;
			header("location: blocked_account.php");
			exit;
		}
     		if ($u_password==$password ) {
			$_SESSION['sess_uid'] 		= $u_id;
			$_SESSION['sess_username'] 	= $u_username2;
			$_SESSION['sess_email']		= $u_email;
			$_SESSION['sess_mobile']	= $u_mobile;
			$_SESSION['sess_fname']		= $u_fname;
			$_SESSION['sess_date']		= $u_date;
			$_SESSION['sess_join_mode']	= $u_join_mode;
			if($u_group=='' || $u_group<2){
 			$_SESSION['sess_group']     = 1;
			} else { 
			$_SESSION['sess_group']     = $u_group;
			}
			
			///$_SESSION['sess_group']     = $u_group;
 			//$_SESSION['sess_security_code']= $u_password2;
  			$sql = "update ngo_users set u_last_login=now() where u_id = '$username'  ";
			$result = db_query($sql);
  			
			if ($_SESSION['sess_back']!='') {
			 	header("location: ".$_SESSION['sess_back']);
				$_SESSION['sess_back']='';	
				exit;	
			} else {
 				 header("location: userpanel/myaccount.php");
				 exit;	
 			}
			
		} else {
				$arr_error_msgs[] =  "Invalid Username/password try again!" ;
				$_SESSION['arr_error_msgs'] = $arr_error_msgs;
				header("Location: login.php");
				exit;
		}
 	} else { 
			$arr_error_msgs[] =  "Invalid Username/password  or Inactive account!" ;
			$_SESSION['arr_error_msgs'] = $arr_error_msgs;
			header("Location: login.php");
			exit;
}
 
?>

<?php
include ("includes/surya.dream.php");
//protect_user_page();
 
 $page='contact_us'; 
 
		
		
if(is_post_back()) {
 
if ($contact_name=='') { $arr_error_msgs[] =  "Your Name is missing!";}
if ($contact_email=='') { $arr_error_msgs[] =  "Your E-mail address is missing!";}
if ($contact_name=='') { $arr_error_msgs[] =  "Your Mobile No is missing!";}
if ($contact_email=='') { $arr_error_msgs[] =  "Your City is missing!";}
if ($contact_comments=='') { $arr_error_msgs[] =  "Your Comments is missing!";}

//if ($_POST['conf_num2']!=$_SESSION['conf_num1']){ $arr_error_msgs[] ="Confirmation number does not match";  }
$_SESSION['arr_error_msgs'] = $arr_error_msgs;
if (count($arr_error_msgs) ==0) {
//contact_city,contact_state,,contact_country
//,'$contact_city','$contact_state','$contact_country'
$contact_name = ms_form_value($contact_name);
$contact_mobile = ms_form_value($contact_mobile);
$contact_email = ms_form_value($contact_email);
$contact_subject = ms_form_value($contact_subject);
$contact_comments = ms_form_value($contact_comments);


 $sqlInsert = "insert into ngo_contact_us (contact_name, contact_mobile, contact_email, contact_subject, contact_comments, contact_date, contact_status) values ('$contact_name','$contact_mobile','$contact_email', '$contact_subject', '$contact_comments', now(), 'Active')";
$result = db_query($sqlInsert);

$MESSAGE = "

Name:        $contact_name

Contact No:  $contact_mobile

Email:       $contact_email

This is regarding: $contact_subject

Message:      $contact_comments ";
$HEADERS  = "MIME-Version: 1.0\r\n";
$HEADERS .= "Content-type: text/plain; charset=iso-8859-1\r\n";
$HEADERS .= "From:  <".$contact_email.">\n";
$SUBJECT  = SITE_NAME." contact us Request";
	
	//@mail(' aaaaaaaaa', $SUBJECT, $MESSAGE,$HEADERS);
	@mail(ADMIN_EMAIL, $SUBJECT, $MESSAGE,$HEADERS);
	#$msgs =  "Thank you for submitting your request" ;
	$arr_error_msgs[] =  "Thank you for submitting your request, we will reach you soon!  " ;
	$status = 'DONE';
	$_SESSION['arr_error_msgs'] = $arr_error_msgs;
	#header("Location: contactus.php");
	#exit;
}
 
} 


?>


<!DOCTYPE html>
<html lang="en">
   <head>
		<?php include ("includes/extra_file.inc.php");?>
 	</head>
    <body class="cnt-home">
		<!-- ============================================== HEADER ============================================== -->
 <?php include ("includes/header.inc.php");?>

<!-- ============================================== HEADER : END ============================================== -->
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'>Contact Us</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
	<div class="container">
    <div class="contact-page">
		<div class="row">
			
				<div class="col-md-12 contact-map outer-bottom-vs">
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d158543.8819112938!2d77.15518029417572!3d28.589036942845624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1579099989903!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
					 
				</div>
				<div class="col-md-9 contact-form">
				<form name="form1" method="post" action="<?=$_SERVER['PHP_SELF']?>" enctype="multipart/form-data"  class="register-form" <?= validate_form()?>>
					 <? include("error_msg.inc.php");?>
	<div class="col-md-12 contact-title">
		<h4>Contact Form</h4>
	</div>
	<div class="col-md-6 ">
		 
		

			<div class="form-group">
		    <label class="info-title" for="exampleInputName">Your Name <span>*</span></label>
			<input name="contact_name" type="text"   class="form-control unicase-form-control text-input"   alt="blank" emsg="Please Enter Name"/> 
		   
		  </div>
		 
	</div>
	<div class="col-md-6">
		 
			<div class="form-group">
		    <label class="info-title" for="exampleInputEmail1">Email Address <span>*</span></label>
		    <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1" placeholder="">
		  </div>
		 
	</div>
	<div class="col-md-6">
		 
			<div class="form-group">
		    <label class="info-title" for="exampleInputTitle">Mobile  <span>*</span></label>
		     	<input name="contact_email" class="form-control unicase-form-control text-input" type="text"  id="contact_email"    alt="blank"  emsg="Please Enter Your  Email"/>
		  </div>
		 
	</div>
	<div class="col-md-6">
		 
			<div class="form-group">
		    <label class="info-title" for="exampleInputTitle">City  <span>*</span></label>
		     	<input name="contact_city" class="form-control unicase-form-control text-input" type="text"  id="contact_city"    alt="blank"  emsg="Please Enter Your City"/>
		  </div>
		 
	</div>
	<div class="col-md-12">
		 
			<div class="form-group">
		    <label class="info-title" for="exampleInputComments">Your Comments <span>*</span></label>
		    
			 <textarea  class="form-control unicase-form-control" name="contact_comments" id="contact_comments"  alt="blank" emsg="Please Enter message  " style="height:100px;"  ></textarea>
		  </div>
		
	</div>
	<div class="col-md-12 outer-bottom-small m-t-20">
		<button type="submit" class="btn-upper btn btn-primary checkout-page-button">Send Message</button>
	</div>
	</form>
</div>
<div class="col-md-3 contact-info">
	<div class="contact-title">
		<h4>Information</h4>
	</div>
	<div class="clearfix address">
		<span class="contact-i"><i class="fa fa-map-marker"></i></span>
		<span class="contact-span">E-208, D Block, Sector 63, Noida, Uttar Pradesh 201301</span>
	</div>
	<div class="clearfix phone-no">
		<span class="contact-i"><i class="fa fa-envelope"></i></span>
		<span class="contact-span"><?=ADMIN_EMAIL?> </span>
	</div>
	<div class="clearfix email">
		<span class="contact-i"><i class="fa fa-envelope"></i></span>
		<span class="contact-span"><a href="#">support@neonimbuss.com</a></span>
	</div>
</div>			</div><!-- /.contact-page -->
		</div><!-- /.row -->
		<!-- ============================================== BRANDS CAROUSEL ============================================== -->
 <?php include ("includes/our_brand.inc.php");?><!-- /.logo-slider --><br>
<!-- ============================================== BRANDS CAROUSEL : END ============================================== -->	</div><!-- /.container -->
</div><!-- /.body-content -->
<!-- ============================================================= FOOTER ============================================================= -->
   <?php include ("includes/footer.inc.php");?>
<!-- ============================================================= FOOTER : END============================================================= -->
<?php include ("includes/extra_footer.inc.php");?>
 
</body>

 </html>


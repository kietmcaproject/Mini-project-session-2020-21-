<div id="header">
    <div class="inner">
      <ul class="main_menu menu_left">
        <li><a href="account.html">My Account</a></li>
        <li><a href="wish.html">Wish List <b>(3)</b></a></li>
        <li><a href="about.html">About Us</a></li>
        <li class="warning"><a href="index.html">Home</a>
          <ul class="secondary">
            <li><a href="index2.html">Home with LI SLIDER</a></li>
          </ul>
        </li>
      </ul>
      <div id="logo"><a href="index.html"><img src="image/logo.png" width="217" height="141" alt="Spicylicious store" /></a></div>
      <ul class="main_menu menu_right">
        <li><a href="compare.html">Compare</a></li>
        <li><a href="cart.html">Shopping Cart</a></li>
        <li><a href="checkout.html">Checkout</a></li>
        <li><a href="contact.html">Contact Us</a></li>
      </ul>
      <div id="welcome"> Welcome visitor you can <a href="#">login</a> or <a href="#">create an account</a>. </div>
      <div class="menu">
        <ul id="topnav">
          <li><a href="category.html">Products</a>
            <ul class="children">
              <li><a href="category.html">Products</a></li>
              <li><a href="category.html">Lasagna</a>
                <ul class="children2">
                  <li><a href="category.html">Products</a></li>
                  <li><a href="category.html">Lasagna</a></li>
                  <li><a href="category.html">Spaghetti</a></li>
                  <li><a href="category.html">Penne</a></li>
                  <li><a href="category.html">Canelonni</a></li>
                </ul>
              </li>
              <li><a href="category.html">Spaghetti</a></li>
              <li><a href="category.html">Penne</a></li>
              <li><a href="category.html">Canelonni</a></li>
            </ul>
          </li>
          <li><a href="category.html">Lasagna</a>
            <ul class="children">
              <li><a href="category.html">Products</a></li>
              <li><a href="category.html">Lasagna</a>
                <ul class="children2">
                  <li><a href="category.html">Products</a></li>
                  <li><a href="category.html">Lasagna</a></li>
                  <li><a href="category.html">Spaghetti</a></li>
                  <li><a href="category.html">Penne</a></li>
                  <li><a href="category.html">Canelonni</a></li>
                </ul>
              </li>
              <li><a href="category.html">Spaghetti</a></li>
              <li><a href="category.html">Penne</a></li>
              <li><a href="category.html">Canelonni</a></li>
            </ul>
          </li>
          <li><a href="category.html">Spaghetti</a></li>
          <li><a href="category.html">Penne</a>
            <ul class="children">
              <li><a href="category.html">Products</a></li>
              <li><a href="category.html">Lasagna</a>
                <ul class="children2">
                  <li><a href="category.html">Products</a></li>
                  <li><a href="category.html">Lasagna</a></li>
                  <li><a href="category.html">Spaghetti</a></li>
                  <li><a href="category.html">Penne</a></li>
                  <li><a href="category.html">Canelonni</a></li>
                </ul>
              </li>
              <li><a href="category.html">Spaghetti</a></li>
              <li><a href="category.html">Penne</a></li>
              <li><a href="category.html">Canelonni</a></li>
            </ul>
          </li>
          <li><a href="category.html">Canelonni</a></li>
          <li><a href="category.html">Fettuchini</a></li>
          <li><a href="category.html">Risotto</a></li>
          <li><a href="category.html">Antipasti</a></li>
          <li><a href="category.html">Bar-B-Q</a></li>
          <li><a href="category.html">Desserts</a></li>
        </ul>
      </div>
    </div>
  </div>
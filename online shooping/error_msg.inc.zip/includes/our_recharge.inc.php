 <div id="ptsblockmanufacturer" class="block ptsblockmanufacturer">
        <h4 class="title_block nostyle"><span style="font-weight:100;">Our Recharge Operator</span></h4>
        <div class="block_content">
          <div id="ptsblockmanufacturer2_bottom" class=" carousel slide">
            <div class="carousel-controls"> <a class="carousel-control left" href="#ptsblockmanufacturer2_bottom" data-slide="prev">&lsaquo;</a> <a class="carousel-control right" href="#ptsblockmanufacturer2_bottom" data-slide="next">&rsaquo;</a> </div>
            <div class="carousel-inner">
              <div class="item  item active">
                <div class="row">
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/1.png" alt="Manufacturer 1" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/2.png" alt="Manufacturer 2" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/3.png" alt="Manufacturer 3" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a  > <img class="img-responsive" src="images/4.png" alt="Manufacturer 4" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/5.png" alt="Manufacturer 5" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/6.png" alt="Manufacturer 6" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/7.png" alt="Manufacturer 7" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a  > <img class="img-responsive" src="images/8.png" alt="Manufacturer-10" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a > <img class="img-responsive" src="images/9.png" alt="Manufacturer-11" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a  > <img class="img-responsive" src="images/10.png" alt="Manufacturer-12" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a  > <img class="img-responsive" src="images/11.png" alt="Manufacturer-13" /> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a  > <img class="img-responsive" src="images/12.png" alt="Manufacturer-14" /> </a> </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item  item ">
                <div class="row">
                  <div class="col-xs-cus-12 col-xs-6 col-sm-6 col-md-1 col-lg-1">
                    <div class="block_manuf clearfix">
                      <div class="blog-image"> <a  > <img class="img-responsive" src="images/13.png" alt="Manufacturer-9" /> </a> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /MODULE Block ptsblockmanufacturer -->
      <script type="text/javascript">
  $(document).ready(function() {
      $('#ptsblockmanufacturer2').each(function(){
          $(this).carousel({
              pause: 'hover',
              interval: false
          });
      });
  });
  </script>
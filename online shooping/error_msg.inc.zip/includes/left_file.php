<div id="column-left">
        <div class="box">
          <h3 class="heading-title"><span>Our Location</span></h3>
          <div class="box-content box-contact-details">
            <ul>
              <li class="address"> <span>Address:</span><br />
               Coming Soon<br />
               <!-- 1715 Sofia, Bulgaria<br />
                Mladost 4 --></li>
              <li class="phone"> <span>Telephone:</span><br />
               Coming Soon</li>
              
            </ul>
          </div>
        </div>
      </div>
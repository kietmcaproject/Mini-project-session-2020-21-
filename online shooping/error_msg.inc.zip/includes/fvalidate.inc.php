<script type="text/javascript" src="<?=SITE_WS_PATH?>/includes/fvalidate/fValidate.config.js"></script>
<script type="text/javascript" src="<?=SITE_WS_PATH?>/includes/fvalidate/fValidate.core.js"></script>
<script type="text/javascript" src="<?=SITE_WS_PATH?>/includes/fvalidate/fValidate.lang-enUS.js"></script>
<script type="text/javascript" src="<?=SITE_WS_PATH?>/includes/fvalidate/fValidate.validators.js"></script>
<?php
if(!defined('LOCAL_MODE')) {
	die('<span style="font-family: tahoma, arial; font-size: 11px">config file cannot be included directly');
}

if (LOCAL_MODE) {
    // Settings for local midas server do not edit here
    $ARR_CFGS["db_host"] = 'localhost';
 	$ARR_CFGS["db_name"] = 'housingrental.com';
    $ARR_CFGS["db_user"] = 'root';
    $ARR_CFGS["db_pass"] = '';
	define('SITE_SUB_PATH', '/housingrental.com');
} else {
  // Settings for live server edit whenever shifting site to different server
  // database settings
  	$ARR_CFGS["db_host"] = 'localhost';
	$ARR_CFGS["db_name"] = 'neonimbuss_a5d4df654a56sd4f65a4sd65f465asdf';
	$ARR_CFGS["db_user"] = 'neonimbuss_asdjklfjaskdljflksajdlfkjasusers';
	$ARR_CFGS["db_pass"] = 'sk.udKXRjZ*ek2.udKXRjZ*ek2.udKXRjZ*ek2neo';
	define('SITE_SUB_PATH', '');
}

define('SITE_WS_PATH', 'http://'.$_SERVER['HTTP_HOST'].SITE_SUB_PATH);

define('THUMB_CACHE_DIR', 'thumb_cache');
define('PLUGINS_DIR', 'includes/plugins');

define('UP_FILES_FS_PATH', SITE_FS_PATH.'/uploaded_files');
define('UP_FILES_WS_PATH', SITE_WS_PATH.'/uploaded_files');

define('DEFAULT_START_YEAR', 2010);
define('DEFAULT_END_YEAR', date('Y')+10);

define('ADMIN_EMAIL', 'info@housingrental.com');
define('SITE_NAME', 'Housing Rental');
define('SITE_TITLE', 'Housing Rental');
define('SITE_URL', 'housingrental.com');
define('TEST_MODE', false);

define('DEF_PAGE_SIZE', 9);
define('SITE_CSS', 'main.css');


?>
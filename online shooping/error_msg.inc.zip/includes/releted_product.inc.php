<div id="ptsblockrelatedproducts" class="col-xs-12 col-sm-12 col-md-12  carousel slide clearfix">

		<div class="block block-default products_block ptsblockrelatedproducts">

			<h4 class="title_block"><span>Related product</span></h4>

			<div class="block_content">
 
					<div id="ptsblockrelatedproducts_top" class="slide carousel boxcarousel products_block">

			 	<a class="carousel-control left" href="#ptsblockrelatedproducts_top"   data-slide="prev">&lsaquo;</a>

			<a class="carousel-control right" href="#ptsblockrelatedproducts_top"  data-slide="next">&rsaquo;</a>

		<div class="carousel-inner">
		
		

			 <!-- Products list -->

			<div class=" item active">

				<ul class="grid products-block row">
				
				 <? 
								$sql= "select * from ngo_products where prod_status='Active'  and prod_catid='$_REQUEST[cat_id]' and prod_id!='$_REQUEST[prod_id]' order by prod_id desc  ";
								$sql .= "limit 0,4 ";
								$result = db_query($sql);
								$ctr_class = 1;
								while($line=  (mysqli_fetch_array($result)))	{
								@extract($line);
						 
						?>		 
					  
                        <li <? if ($ctr_class=='1') { ?>class="ajax_block_product col-cus-xs-12 col-xs-6 col-sm-6 col-md-3 col-lg-3  first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line" <? } else { ?>class="ajax_block_product col-cus-xs-12 col-xs-6 col-sm-6 col-md-3 col-lg-3  last-line last-item-of-tablet-line last-item-of-mobile-line" <? } ?>>
						
						
						
						
						
						
						
                          <div class="product-block " itemscope itemtype="#">
                            <div class="product-container">
                              <div class="left-block">
                                <div class="product-image-container image"> 
								<a class="img product_img_link"	href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" title="<?=str_stop($prod_name,50)?>" itemprop="url">
								<? if (($line['prod_image']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line['prod_image']))) { 
				$ctr_skip++;
				?>
	 <img class="replace-2x img-responsive pts-image" src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line['prod_image'],310,272,'resize')?>" alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
             
              <? }  else { ?>
				<img class="replace-2x img-responsive pts-image" src="images/no_product_pic1.png"  alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
				<? }  ?>
								
		 					  </a> 
								  
								  
								  <span class="hover-image">
	 <a class="img-back product_img_link" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" title="<?=str_stop($prod_name,50)?>" >
	 
	 	<? if (($line['prod_image_hover']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line['prod_image_hover']))) { 
				$ctr_skip++;
				?>
	 <img class="replace-2x img-responsive pts-image" src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line['prod_image_hover'],310,272,'resize')?>"   title="<?=str_stop($prod_name,50)?>" itemprop="image" />
             
              <? }  else { ?>
				<img class="replace-2x img-responsive pts-image" src="images/no_product_pic2.png"  title="<?=str_stop($prod_name,50)?>" itemprop="image" />
				<? }  ?>
	 
	  
	  
	  
	   </a> </span>
                                  <meta itemprop="priceCurrency" content="USD" />
                                  <span class="product-label content_price_percent sale-percent-box" itemprop="offers" itemscope itemtype="#"> <!--<span class="price-percent-reduction sale-label">-15%</span>--> </span> <span class="product-label new-box"> <span class="new-label">New</span> </span>
                                  <div class="pts-atchover"> <a class="btn btn-default quick-view" title="Quick view" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="#"> <i class="icon-search-plus"></i> <span>Quick view</span> </a> </div>
                                </div>
                              </div>
                              <div class="right-block">
                                <div class="product-meta">
                                  <h4 class="name" itemprop="name"> <a class="product-name" href="#" title="<?=str_stop($prod_name,50)?> " itemprop="url" > <?=str_stop($prod_name,50)?> </a> </h4>
                                  <div class="product-desc description" >&nbsp;&nbsp; <? //=str_stop($prod_name,50)?> </div>
                                  <div itemprop="offers" itemscope itemtype=" " class="content_price price"> <span itemprop="price" class="product-price">Price Rs. <?=$prod_mrp?> </span>
                                  <!--  <meta itemprop="priceCurrency" content="INR" />
                                    <span class="old-price product-price"> Rs.	<?=$prod_mrp?> </span> --></div>
                                  <hr />
                                  <!--<div class="comments_note clearfix" itemprop="aggregateRating" itemscope itemtype="#">
                                    <div class="star_content  pull-left clearfix">
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star"></div>
                                      <meta itemprop="worstRating" content = "0" />
                                      <meta itemprop="ratingValue" content = "4" />
                                      <meta itemprop="bestRating" content = "5" />
                                    </div>
                                    <span class="nb-comments pull-right"><span itemprop="reviewCount">1</span> Review(s)</span> </div>
                                  <div class="product-flags"> <span class="discount">Reduced price!</span> </div>-->
                                  <div class="button-container action">
                                    <div   style="width:170px;"><a data-toggle="tooltip"   href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="nofollow" title="View Details" data-id-product="10">&nbsp;&nbsp; 
							<i class=" icon-shopping-cart"></i>	<em>&nbsp;View Product's Details</em> </a></div>
								 
                                   
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- .product-container> -->
                          </div>
						  
						  
						  
						  
						  
						  
						  
                        </li>
					
						<? $ctr_class++;
						//if ($ctr_class=='10')
						//{$ctr_class = 1; }
						
						 } ?>	
				
				
				 

								</ul>

			</div>

				<!-- Products list -->

			<div class=" item ">

				<ul class="grid products-block row">

									
  
					    <? 
								$sql= "select  * from ngo_products where prod_status='Active'  and prod_catid='$_REQUEST[cat_id]'   order by prod_id desc  ";
								$sql .= "limit 4,8 ";
								$result = db_query($sql);
								$ctr_class = 1;
								while($line=  (mysqli_fetch_array($result)))	{
								@extract($line);
						 
						?>		 
					  
                        <li <? if ($ctr_class=='1') { ?>class="ajax_block_product col-cus-xs-12 col-xs-6 col-sm-6 col-md-3 col-lg-3  first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line" <? } else { ?>class="ajax_block_product col-cus-xs-12 col-xs-6 col-sm-6 col-md-3 col-lg-3  last-line last-item-of-tablet-line last-item-of-mobile-line" <? } ?>>
						
						
						
						
						
						
						
                          <div class="product-block " itemscope itemtype="#">
                            <div class="product-container">
                              <div class="left-block">
                                <div class="product-image-container image"> 
								<a class="img product_img_link"	href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" title="<?=str_stop($prod_name,50)?>" itemprop="url">
								<? if (($line['prod_image']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line['prod_image']))) { 
				$ctr_skip++;
				?>
	 <img class="replace-2x img-responsive pts-image" src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line['prod_image'],310,272,'resize')?>" alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
             
              <? }  else { ?>
				<img class="replace-2x img-responsive pts-image" src="images/no_product_pic1.png"  alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
				<? }  ?>
								
		 					  </a> 
								  
								  
								  <span class="hover-image">
	 <a class="img-back product_img_link" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" title="<?=str_stop($prod_name,50)?>" >
	 
	 	<? if (($line['prod_image_hover']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line['prod_image_hover']))) { 
				$ctr_skip++;
				?>
	 <img class="replace-2x img-responsive pts-image" src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line['prod_image_hover'],310,272,'resize')?>"   title="<?=str_stop($prod_name,50)?>" itemprop="image" />
             
              <? }  else { ?>
				<img class="replace-2x img-responsive pts-image" src="images/no_product_pic2.png"  title="<?=str_stop($prod_name,50)?>" itemprop="image" />
				<? }  ?>
	 
	  
	  
	  
	   </a> </span>
                                  <meta itemprop="priceCurrency" content="USD" />
                                  <span class="product-label content_price_percent sale-percent-box" itemprop="offers" itemscope itemtype="#"> <!--<span class="price-percent-reduction sale-label">-15%</span>--> </span> <span class="product-label new-box"> <span class="new-label">New</span> </span>
                                  <div class="pts-atchover"> <a class="btn btn-default quick-view" title="Quick view" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="#"> <i class="icon-search-plus"></i> <span>Quick view</span> </a> </div>
                                </div>
                              </div>
                              <div class="right-block">
                                <div class="product-meta">
                                  <h4 class="name" itemprop="name"> <a class="product-name" href="#" title="<?=str_stop($prod_name,50)?> " itemprop="url" > <?=str_stop($prod_name,50)?> </a> </h4>
                                  <div class="product-desc description" >&nbsp;&nbsp; <? //=str_stop($prod_name,50)?> </div>
                                  <div itemprop="offers" itemscope itemtype=" " class="content_price price"> <span itemprop="price" class="product-price">Price Rs. <?=$prod_mrp?> </span>
                                  <!--  <meta itemprop="priceCurrency" content="INR" />
                                    <span class="old-price product-price"> Rs.	<?=$prod_mrp?> </span> --></div>
                                  <hr />
                                  <!--<div class="comments_note clearfix" itemprop="aggregateRating" itemscope itemtype="#">
                                    <div class="star_content  pull-left clearfix">
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star star_on"></div>
                                      <div class="star"></div>
                                      <meta itemprop="worstRating" content = "0" />
                                      <meta itemprop="ratingValue" content = "4" />
                                      <meta itemprop="bestRating" content = "5" />
                                    </div>
                                    <span class="nb-comments pull-right"><span itemprop="reviewCount">1</span> Review(s)</span> </div>
                                  <div class="product-flags"> <span class="discount">Reduced price!</span> </div>-->
                                  <div class="button-container action">
                                    <div   style="width:170px;"><a data-toggle="tooltip"   href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="nofollow" title="View Details" data-id-product="10">&nbsp;&nbsp; 
							<i class=" icon-shopping-cart"></i>	<em>&nbsp;View Product's Details</em> </a></div>
								 
                                   
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- .product-container> -->
                          </div>
						  
						  
						  
						  
						  
						  
						  
                        </li>
					
						<? $ctr_class++;
						//if ($ctr_class=='10')
						//{$ctr_class = 1; }
						
						 } ?>		
						
						 
						 
					

					

																				 

								</ul>

			</div>

		</div>

</div>











							</div>

		</div>

	</div>

	<script type="text/javascript">

	$(document).ready(function() {

	    $('ptsblockrelatedproducts').each(function(){

	        $(this).carousel({

	            pause: true,

	            interval: 800

	        });

	    });

	});

	</script>
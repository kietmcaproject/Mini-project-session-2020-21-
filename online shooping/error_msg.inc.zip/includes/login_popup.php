
<div id='mask'></div>
<div id='modal_window3' class='modal_window'>
  <table width="600px" border="0" cellspacing="0" cellpadding="0">
    <tr bgcolor="#006666" background="images/txt-header-repeat.jpg">
      <td height="30"><div>
          <div id="m_head_txt">Sign In</div>
          <a href="#" title="Close">
          <div class='close_modal'>x</div>
          </a></div></td>
    </tr>
    <tr>
      <td><div id ="cont">
          <table width="100%" height="200px">
            <tr>
              <td align="left" valign="top"><form id="form2" method="post" style="margin:0px;" action="login_func.php"  enctype="application/x-www-form-urlencoded" <?= validate_form()?>>
                  <table width="688" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td height="207" align="center"><table width="476" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="145"><img src="images/Login.png" width="128" height="128" /></td>
                            <td width="331"><table width="331" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                  <td height="20">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td height="44" class="padding"><input name="username" value="<?=$username?>" class="input" /></td>
                                </tr>
                                <tr>
                                  <td >&nbsp;</td>
                                </tr>
                                <tr>
                                  <td height="37" class="padding"><input type="password" name="password" value="<?=$password?>" class="input"/></td>
                                </tr>
                                <tr>
                                  <td>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td><table width="323" border="0" cellspacing="0" cellpadding="0">
                                      <tr>
                                        <td width="231"><table border="0" cellpadding="0" cellspacing="0" width="151">
                                            <tr>
                                              <td align="left" width="151"><a href="forgot_password.php"> <span class="forgot_password">Forgot You Password ?</span></a></td>
                                            </tr>
                                          </table></td>
                                        <td width="105"><input name="submit" type="submit" src="images/submit.png" value="Login" class="button_example"  />
                                        </td>
                                      </tr>
                                    </table></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
                </form></td>
            </tr>
          </table>
        </div></td>
    </tr>
  </table>
</div>

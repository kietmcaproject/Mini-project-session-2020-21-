 <footer id="footer" class="footer color-bg">
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-3">
          <div class="module-heading">
            <h4 class="module-title">About Us</h4>
          </div>
          <!-- /.module-heading -->
          
          <div class="module-body">
            <ul class="toggle-footer" style="">
              <li class="media">
                <div class="pull-left"> <span class="icon fa-stack fa-lg"> <i class="fa fa-pintrest fa-stack-1x fa-inverse">H</i> </span> </div>
                <div class="media-body">
                  <p>ousing Rental
                  are the India's best Rental Portal. We Bring wide range of product on valuable price. You can Use Our Products from the list. <?=SITE_NAME?> is a one-stop shop for all your online housing needs. It is a leading online rental portal 
                  <a style="float:right;" href="about_us.php">Read More...</a> </p>
                </div>
              </li>
               
               
            </ul>
          </div>
          <!-- /.module-body --> 
        </div>
        <!-- /.col -->
        
        <div class="col-xs-12 col-sm-6 col-md-3">
          <div class="module-heading">
            <h4 class="module-title">Company Profile</h4>
          </div>
          <!-- /.module-heading -->
          
          <div class="module-body">
            <ul class='list-unstyled'>
			
			<li  class="first"><a href="about_us.php" title="About Us" rel="nofollow">About Us</a></li>
            <li><a href="#" title="Terms & Condition" rel="nofollow">Terms & Condition</a></li>
            <li><a href="#" title="Privacy Policy" rel="nofollow">Privacy Policy</a></li>
            <li><a href="#" title="Disclaimer" rel="nofollow">Disclaimer</a></li>
			<li><a href="#" title="Refund Policy" rel="nofollow">Refund Policy</a></li>
			<li class="last"> <a href="contact_us.php" title="Contact Us" class="img"> Contact Us</a> </li>
			
			
			
              
            </ul>
          </div>
          <!-- /.module-body --> 
        </div>
        <!-- /.col -->
        
       
        <!-- /.col -->
        
        <div class="col-xs-12 col-sm-6 col-md-3">
          <div class="module-heading">
            <h4 class="module-title">Featured Products</h4>
          </div>
          <!-- /.module-heading -->
          
          <div class="module-body">
            <ul class='list-unstyled'>
               
             <li  class="first"><a href="#"  rel="nofollow">Table</a></li>
			 
			  <li  class="first"><a href="#"   rel="nofollow">Chair</a></li>
			    <li  class="first"><a href="#"  rel="nofollow">Bed</a></li>
				
				  <li  class="first"><a href="#"   rel="nofollow">Couch</a></li>
             
            </ul>
          </div>
          <!-- /.module-body --> 
        </div>
		<div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="module-heading">
                        <h4 class="module-title">Contact Us</h4>
                    </div><!-- /.module-heading -->

                    <div class="module-body">
        <ul class="toggle-footer" style="">
            <li class="media">
                <div class="pull-left">
                     <span class="icon fa-stack fa-lg">
                            <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                    </span>
                </div>
                <div class="media-body">
                    <p>Kiet College, Ghaziabad,

  Uttar Pradesh 201206</p>
                </div>
            </li>

              <li class="media">
                <div class="pull-left">
                     <span class="icon fa-stack fa-lg">
                      <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                    </span>
                </div>
                <div class="media-body">
                    <p>info@kiet.edu </p>
                </div>
            </li>

              <li class="media">
                <div class="pull-left">
                     <span class="icon fa-stack fa-lg">
                      <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                    </span>
                </div>
                <div class="media-body">
                   <p>support@kiet.edu </p>
                </div>
            </li>
              
            </ul>
    </div><!-- /.module-body -->
                </div>
      </div>
    </div>
  </div>
  <div class="copyright-bar">
    <div class="container">
      <div class="col-xs-12 col-sm-4 no-padding social">
        <ul class="link">
          <li class="fb pull-left"><a target="_blank" rel="nofollow" href="#" title="Facebook"></a></li>
          <li class="tw pull-left"><a target="_blank" rel="nofollow" href="#" title="Twitter"></a></li>
          <li class="googleplus pull-left"><a target="_blank" rel="nofollow" href="#" title="GooglePlus"></a></li>
          <li class="rss pull-left"><a target="_blank" rel="nofollow" href="#" title="RSS"></a></li>
          <li class="pintrest pull-left"><a target="_blank" rel="nofollow" href="#" title="PInterest"></a></li>
          <li class="linkedin pull-left"><a target="_blank" rel="nofollow" href="#" title="Linkedin"></a></li>
          <li class="youtube pull-left"><a target="_blank" rel="nofollow" href="#" title="Youtube"></a></li>
        </ul>
      </div>
      <div class="col-xs-12 col-sm-4 no-padding">
        <div  style="text-align:center">
          <p style="color:#FFFFFF"> &copy; 2021 <?=SITE_URL?></p>
        </div>
        <!-- /.payment-methods --> 
      </div>
	  <div class="col-xs-12 col-sm-4 no-padding">
        <div class="clearfix payment-methods">
          <ul>
            <li><img src="assets/images/payments/1.png" alt=""></li>
            <li><img src="assets/images/payments/2.png" alt=""></li>
            <li><img src="assets/images/payments/3.png" alt=""></li>
            <li><img src="assets/images/payments/4.png" alt=""></li>
            <li><img src="assets/images/payments/5.png" alt=""></li>
          </ul>
        </div>
        <!-- /.payment-methods --> 
      </div>
    </div>
  </div>
</footer>





<marquee align="top" direction="left"   height="195" width="945"   scrollamount="3"  onmouseover="this.stop()" onmouseout="this.start()">
<table width="100%" border="0" cellspacing="2" cellpadding="2" >
  <tr>
    <?
 	$sql_scroll= "select  * from ngo_products where prod_status='Active' and prod_featured='featured' order by prod_id asc limit 0, 20 ";
	$result_scroll = db_query($sql_scroll);
 	while($line_scroll=  (mysqli_fetch_array($result_scroll)))	{
	@extract($line_scroll);
  	?>
    <td align="center" valign="top">
	<table border="0" align="center"  class="txtbox">
        <tr>
          <td  align="center" ><a href="product_details.php?prod_id=<?=$line_scroll[prod_id]?>" class="readmoretxt">
            <? if (($line_scroll['prod_image']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line_scroll['prod_image']))) { ?>
            <img src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line_scroll['prod_image'],150,120,'resize')?>"  align="center" class="border_member" border="0"/>
            <? } ?>
            </a> </td>
        </tr>
      </table></td>
    <?
 	}
 
  
?>
  </tr>
</table>
</marquee>

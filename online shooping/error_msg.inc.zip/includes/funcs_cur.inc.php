<?
function validate_form()
{
	return ' onsubmit="return validateForm(this,0,0,0,1,8);" ';
}

/////////////////////// recharge function start //////////////////////
function operator_dropdown($name,$sel_value,$type,$extra){
	$sql ="select opt_code , opt_name from ngo_operator_comp where opt_status='Active' and opt_type='$type'  order by opt_name";  
	return make_dropdown($sql, $name, $sel_value,  'class="wpcf8-form-control wpcf_rk8-text wpcf8-validates-as-required" alt="select"  style="width:198px;border:1px solid #d4d4d4;"','Please select');
 }
 
 
 function operator_plan_type_dropdown($name,$sel_value){
	$ARR_RECHARGE_PLAN_TYPE = array( "FULL TALKTIME" => 'FULL TALKTIME', 'TOPUP' => 'TOPUP', '3G' => '3G','2G' => '2G','OTHER' => 'OTHER');
	return array_dropdown($ARR_RECHARGE_PLAN_TYPE, $sel_value, $name);
}
 
/*
function allbillpay_mobile_recharge($username,$trpass,$mobileno,$amount,$opt_code, $opt_name) {
 
 if ($mobileno!='' && $amount!='') {
 		// my allbillpay username and password
		$username='9711762469';
		$trpass ='971176';
  		$url = "http://allbillpay.com/MDDAPI/Mob_API.php?username=$username&trpass=$trpass&mobile=$mobileno&opid=$opt_code&amount=$amount&opname=$opt_name";
  		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$curl_scraped_page = curl_exec($ch);
		curl_close($ch);
		return $curl_scraped_page;
		// .'==>'.$url
  }
	 
}*/

function allbillpay_mobile_recharge($username,$trpass,$mobileno,$amount,$opt_code, $opt_name) {
/* 
 if ($mobileno!='' && $amount!='') {
 		// my allbillpay username and password
		$username='tapubaba';
		$trpass ='D3C251C8';
  		$url = "http://allbillpay.com/MDDAPI/Mob_API.php?username=$username&trpass=$trpass&mobile=$mobileno&opid=$opt_code&amount=$amount&opname=$opt_name";
  		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$curl_scraped_page = curl_exec($ch);
		curl_close($ch);
		return $curl_scraped_page;
		// .'==>'.$url
  }*/
	if ($mobileno!='' && $amount!='') {
 		// my paypayo username and password
	$username='tapubaba';
	$trpass ='D3C251C8';
 $url="https://allbillpay.com/MDDAPI/Mob_API.php";
 $message = urlencode($message);
 $ch = curl_init(); 
 if (!$ch){die("Couldn't initialize a cURL handle");}
 $ret = curl_setopt($ch, CURLOPT_URL,$url);
 curl_setopt ($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
 curl_setopt ($ch, CURLOPT_POSTFIELDS,"username=$username&trpass=$trpass&mobile=$mobileno&opid=$opt_code&amount=$amount&opname=$opt_name");
 $ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

 
$curlresponse = curl_exec($ch); // execute
if(curl_errno($ch))
	echo 'curl error : '. curl_error($ch);

 if (empty($ret)) {
    // some kind of an error happened
    die(curl_error($ch));
    curl_close($ch); // close cURL handler
 } else {
    $info = curl_getinfo($ch);
    curl_close($ch); // close cURL handler
    //echo "<br>";
	return $curlresponse;    //echo "Message Sent Succesfully" ;
  }
  
  } 
	 
	 
}



////////////////////////// Recharge end ////////////////////////

function send_sms_text($mobilenumbers,$message,$msg_id='') {
 if ($mobilenumbers!='' && $message!='') {
  	 $url = "http://textart.in/sendhttp.php?user=".urlencode('smsapi')."&password=".urlencode('AAAAAAA')."&mobiles=".urlencode($mobilenumbers)."&message=".urlencode($message)."&sender=".urlencode('AAAAAA')."&route=4";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$curl_scraped_page = curl_exec($ch);
	curl_close($ch);
	//echo $curl_scraped_page;
 	return $curl_scraped_page; 
  	 }
 }


 

function send_sms_outofservice($mobilenumbers,$message,$msg_id='') {
 
if ($mobilenumbers!='' && $message!='') {

 //	$url = "http://textart.in/sendhttp.php?user=".urlencode('globalcab')."&password=".urlencode('118936')."&mobiles=".urlencode($mobilenumbers)."&message=".urlencode($message)."&sender=".urlencode('GLOBAL')."&route=4";
 
  $url = "http://103.16.101.52/sendsms/bulksms?username=".urlencode('017-globalcab')."&password=".urlencode('123456')."&destination=".urlencode($mobilenumbers)."&message=".urlencode($message)."&source=".urlencode('GLOBAL')."&type=0&dlr=1";
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$curl_scraped_page = curl_exec($ch);
	curl_close($ch);
	//echo $curl_scraped_page;
 	return $curl_scraped_page; 
  	 }
 }


 

function send_sms ($mobilenumbers,$message,$msg_id='') {
 
if ($mobilenumbers!='' && $message!='') {
// http://103.247.98.91/API/SendMsg.aspx?uname=xxxxxxxx&pass=xxxxx&send=xxxxxx&dest=xxxxxxxxxx&msg=xxxxxxx&priority=1&schtm=xxxx-xx-xx xx:xx
 
//Please Enter Your Details
 $uname="20191575xxxxxxxxx"; //your username
 $pass="9W90T7tk"; //your password
 #$mobilenumbers="919XXXXXXXXX"; //enter Mobile numbers comma seperated
 #$message = "test messgae"; //enter Your Message 
 $send="";//Your senderid
 $priority="1"; //Type Of Your Message
 $schtm=""; //Delivery Reports
 #$url="http://www.smscountry.com/SMSCwebservice.asp";
 #$url="api.smscountry.com/SMSCwebservice_bulk.aspx";
 $url="http://103.247.98.91/API/SendMsg.aspx";
 $message = urlencode($message);
 $ch = curl_init(); 
 if (!$ch){die("Couldn't initialize a cURL handle");}
 $ret = curl_setopt($ch, CURLOPT_URL,$url);
 curl_setopt ($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
 curl_setopt ($ch, CURLOPT_POSTFIELDS,"uname=$uname&pass=$pass&send=PAYPYO&dest=$mobilenumbers&msg=$message");
 $ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

 

 $curlresponse = curl_exec($ch); // execute
if(curl_errno($ch))
	echo 'curl error : '. curl_error($ch);

 if (empty($ret)) {
    // some kind of an error happened
    die(curl_error($ch));
    curl_close($ch); // close cURL handler
 } else {
    $info = curl_getinfo($ch);
    curl_close($ch); // close cURL handler
    //echo "<br>";
	return $curlresponse;    //echo "Message Sent Succesfully" ;
  }
 }
	 
}

function send_sms2($sms_mobile,$message,$msg_id='') {
 
if ($sms_mobile!='' && $message!='') {
// http://103.247.98.91/API/SendMsg.aspx?uname=xxxxxxxx&pass=xxxxx&send=xxxxxx&dest=xxxxxxxxxx&msg=xxxxxxx&priority=1&schtm=xxxx-xx-xx xx:xx
 
//Please Enter Your Details
 $uname="20151178"; //your username
 $pass="123456"; //your password
 #$mobilenumbers="919XXXXXXXXX"; //enter Mobile numbers comma seperated
 #$message = "test messgae"; //enter Your Message 
 $send="aaaaaaaaa"; //Your senderid
 $priority="1"; //Type Of Your Message
 $schtm=""; //Delivery Reports
 #$url="http://www.smscountry.com/SMSCwebservice.asp";
 #$url="api.smscountry.com/SMSCwebservice_bulk.aspx";
 $url="http://103.247.98.91/API/SendMsg.aspx";
 $message = urlencode($message);
 $ch = curl_init(); 
 if (!$ch){die("Couldn't initialize a cURL handle");}
 $ret = curl_setopt($ch, CURLOPT_URL,$url);
 curl_setopt ($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);          
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
 curl_setopt ($ch, CURLOPT_POSTFIELDS,"uname=$uname&pass=$pass&send=OPENKT&dest=$sms_mobile&msg=$message");
 $ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

 

 $curlresponse = curl_exec($ch); // execute
if(curl_errno($ch))
	echo 'curl error : '. curl_error($ch);

 if (empty($ret)) {
    // some kind of an error happened
    die(curl_error($ch));
    curl_close($ch); // close cURL handler
 } else {
    $info = curl_getinfo($ch);
    curl_close($ch); // close cURL handler
    //echo "<br>";
	return $curlresponse;    //echo "Message Sent Succesfully" ;
  }
 }
	 
}

 

function protect_admin_page() {
	//return true;
	 $cur_dir = dirname($_SERVER['PHP_SELF']);
	if($cur_dir == SITE_SUB_PATH.'/admin') {
		$cur_page = basename($_SERVER['PHP_SELF']);
		 //echo "<br>cur_page: $cur_page";
		if($cur_page != 'login.php') {
			if ($_SESSION['sess_admin_login_id']=='') {
			#	header('Location: login.php');
			#	exit;
			}
		}
	}
}

function protect_admin_page2() {

	if ($_SESSION['sess_admin_login_id']=='') {
 		header('Location: login.php');
		exit;
	}
}

function protect_user_page() {

	if ($_SESSION['sess_uid']=='') {
 		$_SESSION['sess_back']=basename($_SERVER['PHP_SELF'])."?".$_SERVER['QUERY_STRING'];
		header('Location: login.php');
		exit;
	}
}
 
 
 function redirect_payment_page() {

	//$my_investment = db_scalar("select sum(topup_amount) from ngo_users_recharge  where topup_userid  = '$_SESSION[sess_uid]' ")+0;
 	/*$u_status = db_scalar("select u_status from ngo_users where u_id  = '$_SESSION[sess_uid]' ");
	if ($u_status=='Inactive') {
 		header('Location: my_ewallet_acc_activation.php');
		exit;
	}*/
	
}
 

 
 
function get_sponsor_id($u_ref_userid,$u_ref_side){
  	while ($sb!='stop'){
		$u_id = db_scalar("select u_id from ngo_users  where  u_sponsor_id ='$u_ref_userid' and u_ref_side='$u_ref_side' limit 0,1");
		if ($u_id!='') { $u_ref_userid = $u_id; } else { $sb='stop';}
  } 
 return $u_ref_userid;
}


  
/// Sajax Funtion Start 


function get_username_details($name='username_details',$username) {
	//check uesrname availability
	 
	///if ($username!='') { $sql_part = " and u_username= '$username' ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
	if ($username!='') { $sql_part = " and ( u_mobile = '$username' OR u_username2='$username' ) "; } else { $sql_part = " and u_id= '$_SESSION[sess_uid]' "; }
	$sql_you  = "select u_id,u_fname from ngo_users where 1 $sql_part ";
	$result_you  = db_query($sql_you);
	$line_you   = mysqli_fetch_array($result_you );
	 //return "OK" .$line_you[u_id];
	if ($line_you[u_id]!='') {
		return 'Username <span class="error">(Not Available)</span>';
	} else {
		return 'Username <span class="error">(Available)</span>';
	}
  	
}
function get_sponsor_details($name='sponsor_details',$ref_userid) {
	//check uesrname availability
	
	//if ($ref_userid!='') { $sql_part = " and u_username= '$ref_userid' ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
	
	if ($ref_userid!='') { $sql_part = " and (u_mobile = '$ref_userid' OR u_username='$ref_userid') ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
	$sql_you  = "select u_id, u_fname from ngo_users where 1 $sql_part ";
	$result_you  = db_query($sql_you);
	$line_you   = mysqli_fetch_array($result_you );
	 //return "OK" .$line_you[u_id];
	if ($line_you[u_id]!='') {
		return '<span class="error">'.$line_you[u_fname].' </span>';
	} else {
		return '<span class="error">Wrong Placement Information</span>';
	}
  	
}

function get_referal_details($name='referal_details',$ref_userid) {
	//check uesrname availability
 	///if ($ref_userid!='') { $sql_part = " and u_username= '$ref_userid' ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
 	if ($ref_userid!='') { $sql_part = " and (u_mobile = '$ref_userid' OR u_username='$ref_userid')  ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
	$sql_you  = "select u_id, u_fname from ngo_users where 1 $sql_part ";
	$result_you  = db_query($sql_you);
	$line_you   = mysqli_fetch_array($result_you );
	 //return "OK" .$line_you[u_id];
	if ($line_you[u_id]!='') {
		return '<span class="error">'.$line_you[u_fname].'</span>';
	} else {
		return '<span class="error">Wrong Introducer  Information</span>';
	}
  	
}
function get_user_details($name='user_details',$topup_username) {
	//check uesrname availability
	 //return "OK";
 
	if ($topup_username!='') { $sql_part = " and u_username= '$topup_username' ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
	$sql_you  = "select * from ngo_users where  u_username= '$topup_username' ";
	$result_you  = db_query($sql_you );
	$line_you   = mysqli_fetch_array($result_you );
  	//aassmapvt.com
	if (($line_you[u_photo]!='')&& (file_exists(UP_FILES_FS_PATH.'/profile/'.$line_you[u_photo]))) {  
$photo = '<img src="'.show_thumb(UP_FILES_WS_PATH.'/profile/'.$line_you[u_photo],100,100,'height').'" align="left"   style="margin-right:1px; vertical-align:top;" />';
 }   
	$return_msg = '
	<table width="450" border="0" cellspacing="1" cellpadding="1"  >
  <tr>	
	<td width="1"> '.$photo.' </td>
	<td>
 	<table width="100%" border="0" cellspacing="0" cellpadding="0"  >
	<tr  >	
		<td  colspan="2" align="left" class="subtitle" > <strong>User Information</strong></td>
		 
	  </tr>
	  <tr  >	
		<td width="40%" align="right" class="maintxt" > <strong>User ID :</strong></td>
		<td width="60%" class="maintxt" >'.$line_you[u_username].'</td>
	  </tr>
	  <tr  >	
		<td align="right" class="maintxt" > <strong>Name :</strong></td>
		<td    >'.$line_you[u_fname].'</td>
	  </tr>
	  <tr    >
		<td align="right"  class="maintxt"> <strong>Address :</strong></td>
		<td class="maintxt">'. date_format2($line_you[u_address]).'</td>
	  </tr>
	   
	  <tr   >
		<td align="right"  class="maintxt"> <strong>Date of join :</strong></td>
		<td class="maintxt">'. date_format2($line_you[u_date]).'</td>
	  </tr>
	  </table>
	   </td>
	  </tr>
 </table>';
 	return $return_msg;
}

function get_downline_details($name='downline_details',$userid) {
	//check uesrname availability
 	if ($userid!='') { $sql_part = " and u_id= '$userid' ";} else {$sql_part = " and u_id= '$_SESSION[sess_uid]' ";}
	$sql_you  = "select * from ngo_users where 1 $sql_part";
	$result_you  = db_query($sql_you );
	$line_you   = mysqli_fetch_array($result_you );
 
 	$referer_id = db_scalar("select u_username from ngo_users where u_id='$line_you[u_ref_userid]' ");
	$total_topup = db_scalar("select sum(topup_bv) from ngo_users_recharge where topup_userid='$line_you[u_id]' ");
	$topup_date = db_scalar("select topup_date  from ngo_users_recharge where topup_userid='$line_you[u_id]' ");
	$left_side_id = db_scalar("select u_id from ngo_users where u_sponsor_id='$line_you[u_id]' and u_ref_side='A'");
	$right_side_id = db_scalar("select u_id from ngo_users where u_sponsor_id='$line_you[u_id]' and u_ref_side='B'");
		// Sponsor ID
	//$sponsor_id = db_scalar("select u_username from ngo_users where u_id ='$line_you[u_ref_userid]' ");

	//Left-Right Count :
	$total_id_left  = binary_total_ids($left_side_id)+0 ;
	$total_id_right = binary_total_ids($right_side_id)+0 ;
	
	// Left-Right Topup Business :
	
	$total_topup_left  = binary_total_business_bv($left_side_id , "  ")+0;
	$total_topup_right = binary_total_business_bv($right_side_id , "  ")+0 ;
	// Left-Right Recharge Business :	 
	#$total_recharge_left  = binary_total_business_date_range($left_side_id, " and topup_plan='RECHARGE'")+0;
	#$total_recharge_right = binary_total_business_date_range($right_side_id, " and topup_plan='RECHARGE'")+0 ;
	//aassmapvt.com
	if (($line_you[u_photo]!='')&& (file_exists(UP_FILES_FS_PATH.'/profile/'.$line_you[u_photo]))) {  
$photo = '<img src="'.show_thumb(UP_FILES_WS_PATH.'/profile/'.$line_you[u_photo],100,100,'height').'" align="left" border="0"   style="margin-right:1px; vertical-align:top;" />';
 }   
	$return_msg = '
  	  <table width="100%" border="0" cellspacing="3" cellpadding="3" class="td_box"  >
	  <!--<tr class="tdOdd" >
	  <td width="25%" align="right" class="maintxt" > <strong>User ID :</strong></td>
		<td width="25%" class="maintxt" nowrap="nowrap" >'.$line_you[u_username].'</td>
 	    <td width="25%" align="right" class="maintxt" ><strong>Sponsor ID : </strong></td>
	    <td width="25%" align="left" class="maintxt" nowrap="nowrap">'.$referer_id.'</td>	
	   </tr>
	   <td align="right"  class="maintxt"> <strong>Self Package(BV)  :</strong></td>
		<td align="left" class="maintxt">'.   ($total_topup) .'</td>-->
		
	  <tr  class="tdEven"  >
	  <td align="center" width="50%"  class="maintxt" colspan="4"><strong>&nbsp;&nbsp;Name :  </strong> '.$line_you[u_fname].' </td>
		
		
	 </tr>
 	  
	  <tr  class="tdEven" >
	  <td align="left"  class="maintxt"><strong>&nbsp;&nbsp;FBV Left:</strong></td>
		<td align="left" class="maintxt">&nbsp;&nbsp;'. ($aaaaaaaaaaa).' </td>
  		<td align="left"  class="maintxt">&nbsp;&nbsp;<strong>FBV Right:</strong></td>
	    <td align="left"  class="maintxt">&nbsp;&nbsp;'.  ($aaaaaaaaa).' </td>
	  </tr>
	   <tr  class="tdEven" >
	  <td align="left"  class="maintxt">&nbsp;&nbsp;<strong>RBV Left:</strong></td>
		<td align="left" class="maintxt">&nbsp;&nbsp;'.($aaaaaaaaa).' </td>
  		<td align="left"  class="maintxt">&nbsp;&nbsp;<strong>RBV Right:</strong></td>
	    <td align="left"  class="maintxt">&nbsp;&nbsp;'.($aaaaaa).' </td>
	  </tr>
 	  </table>
	   ';
	 
	 
	 
	return $return_msg;
}




/// Sajax Funtion Start 



function binary_total_ids($userid){
	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
 	while ($sb!='stop'){
	$ctr++;
	//if ($ctr>=10) {$sb='stop';}
 	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where u_sponsor_id in ($referid) ";
	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
 		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			  $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
		} else {
			$sb='stop';
		}
	 } 
	 $id = array_unique($id); 
  	$id_in = implode(",",$id); 
 	$total_ids = db_scalar("select count(u_id) from ngo_users  where  u_sponsor_id in ($id_in) ")+1; 
	return $total_ids;
}
}

function binary_total_paid_ids($userid,$sql_part){
	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
 	while ($sb!='stop'){
	$ctr++;
	//if ($ctr>=10) {$sb='stop';}
  	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where u_sponsor_id in ($referid) ";
	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
 		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			  $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
		} else {
			$sb='stop';
		}
	 } 
	 $id = array_unique($id); 
  	$id_in = implode(",",$id); 
	//return "select count(*)   from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part ";
	//$total_ids = db_scalar("select count(*) from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part ");
  	$total_ids = db_scalar("select sum(topup_amount) from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part "); 
	return $total_ids;
}
}
function binary_total_business_date_range($userid ,$sql_part){
 	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
 	while ($sb!='stop'){
	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where u_sponsor_id in ($referid) ";
	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			 $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
		} else {
			$sb='stop';
		}
	 } 
	 $id = array_unique($id); 
	$id_in = implode(",",$id); 
 	 #print  "<br> select sum(topup_amount)  from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part ";
	$total_business = db_scalar("select sum(topup_amount)  from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part ")+0; 
	return $total_business;
}
}

function binary_total_business_bv($userid ,$sql_part){
 	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
 	while ($sb!='stop'){
	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where u_sponsor_id in ($referid) ";
	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			 $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
		} else {
			$sb='stop';
		}
	 } 
	 $id = array_unique($id); 
	$id_in = implode(",",$id); 
 	 #print  "<br> select sum(topup_amount)  from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part ";
	$total_business = db_scalar("select sum(topup_bv)  from ngo_users_recharge  where  topup_userid in ($id_in) $sql_part ")+0; 
	return $total_business;
}
}
function binary_total_business($userid){
 	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
 	while ($sb!='stop'){
	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where u_sponsor_id in ($referid) ";
	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			 $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
			 
		} else {
			$sb='stop';
		}
	 } 
	$id = array_unique($id); 
	$id_in = implode(",",$id); 
 	$total_business = db_scalar("select sum(topup_amount)  from ngo_users_recharge  where  topup_userid in ($id_in) ")+0; 
	return $total_business;
}
}


function binary_total_date($userid,$datefrom,$dateto){
	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
 	while ($sb!='stop'){
	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where    u_sponsor_id in ($referid) ";
	if ($datefrom!='' && $dateto!='') {  $sql_test .= " and u_date between '$datefrom' AND '$dateto' ";  }
 	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			 $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
		} else {
			$sb='stop';
		}
	 } 
	$id = array_unique($id); 
	$id_in = implode(",",$id); 
	//	 print "select count(u_id)  from ngo_users  where  u_sponsor_id in ($id_in) ";

 	$total_ids = db_scalar("select count(u_id)  from ngo_users  where u_status='Active' and  u_sponsor_id in ($id_in) ")+1; 
	return $total_ids;
}
}


function downline_ids($userid){
	if ($userid!=''){
 	$id = array();
	$id[]=$userid;
	
	while ($sb!='stop'){
	if ($referid=='') {$referid=$userid;}
	$sql_test = "select u_id  from ngo_users  where  u_ref_userid in ($referid)  ";
	$result_test = db_query($sql_test);
	$count = mysqli_num_rows($result_test);
		if ($count>0) {
			//print "<br> $count = ".$ctr++;
			$refid = array();
			while ($line_test= mysqli_fetch_array($result_test)){
				$id[]=$line_test[u_id];
				$refid[]=$line_test[u_id];
			}
			 $refid = array_unique($refid); 
			 $referid = implode(",",$refid);
		} else {
			$sb='stop';
		}
	 } 
	$id = array_unique($id); 
	$id_in = implode(",",$id); 
	return $id_in;
}
}


function str_stop($string, $max_length){
	if (strlen($string) > $max_length){
		$string = substr($string, 0, $max_length);
		$pos = strrpos($string, " ");
		if($pos === false) {
			  return substr($string, 0, $max_length)."...";
		  }
		return substr($string, 0, $pos)."...";
	}else{
		return $string;
	}
}


function date_month($date, $format) {
	if (strlen($date) >= 10) {
		if ($date == '0000-00-00 00:00:00' || $date	== '0000-00-00') {
			return '';
		}
		$mktime	= mktime(0,	0, 0, substr($date,	5, 2), substr($date, 8,	2),	substr($date, 0, 4));
		//return date("F", $mktime);
		return date($format, $mktime);
	} else {
		return $s;
	}
}
function cal_age($DOB) { 
 	    $birth = explode("-", $DOB); 
         $age = date("Y") - $birth[0]; 
         if(($birth[1] > date("m")) || ($birth[1] == date("m") && date("d") < $birth[2])) { 
                $age -= 1; 
        } 
        return $age; 
}


function  user_group_dropdown($name,$sel_value,$extra){
// 	( $arr, $sel_value='', $name='', $extra='', $choose_one='', $arr_skip= array())
	global $ARR_USER_GROUP;
	return array_dropdown($ARR_USER_GROUP, $sel_value, $name, $extra);
}


function payment_processor_dropdown($selected,$extra) {
 	global $ARR_PAYMENT_PROCESSOR;
	return array_dropdown($ARR_PAYMENT_PROCESSOR,$selected,'pay_group',$extra);
}
function topup_group_dropdown($name,$sel_value){
	$arr = array('' => 'Please Select', 'JOIN' => 'Registration', 'LOAN' => 'Loan Activation', 'PREMIUM' => 'Premium Package', 'POWER' => 'Premium Package');
	return array_dropdown($arr, $sel_value, $name);
}

function payment_status_dropdown($name,$sel_value){
	$arr = array('' => 'Please Select', 'Paid' => 'Paid', 'Unpaid' => 'Unpaid');
	return array_dropdown($arr, $sel_value, $name);
}
function payment_mode_dropdown($name,$sel_value){
	$arr = array('' => 'Please Select', 'Cash' => 'Cash', 'Cheque' => 'Cheque', 'Other' => 'Other');
	return array_dropdown($arr, $sel_value, $name);
}
function total_ref_dropdown($name,$sel_value){
	$arr = array('' => 'Please Select', '3' => 'Referer 3', '5' => 'Referer 5', '11' => 'Referer 11', '25' => 'Referer 25', '0' => 'Referer 0');
	return array_dropdown($arr, $sel_value, $name);
}

function bank_dropdown($name,$sel_value){
	$arr = array('' => 'Please Select', "ICICI" => 'ICICI', 'BOI' => 'BOI','BOB'=>'BOB','HDFC'=>'HDFC','AXIS'=>'AXIS');
	return array_dropdown($arr, $sel_value, $name);
}

function bank_dropdown2($name,$sel_value){
	$arr = array('' => 'Please Select', "ICICI" => 'ICICI', 'BOI' => 'BOI','BOB'=>'BOB','HDFC'=>'HDFC','AXIS'=>'AXIS','SBI'=>'SBI');
	return array_dropdown($arr, $sel_value, $name);
}

function checkstatus_dropdown($name,$sel_value){
	$arr = array( '' => 'Please Select','Not Deliver' => 'Not Deliver', 'Deliver' => 'Deliver','Cancel'=>'Cancel','New Request'=>'New Request');
	return array_dropdown($arr, $sel_value, $name);
}
function checktype_dropdown($name,$sel_value){
	$arr = array( '' => 'Please Select','PDC' => 'PDC','DIRECT' => 'DIRECT','MATCHING' => 'MATCHING' ,'TRADE_PROFIT'=>'TRADE_PROFIT' ,'GENERAL' => 'GENERAL');
	return array_dropdown($arr, $sel_value, $name);
}

function deduction_dropdown($name,$sel_value,$extra){
	$ARR_DEUCTION = array( '' => 'Please Select','TDS'=>'TDS' );
	 
	return array_dropdown($ARR_DEUCTION,$sel_value,$name,$extra);
}

 

function gender_dropdown($selected,$extra) {
 	
	global $ARR_GENDER;
	return array_dropdown($ARR_GENDER,$selected,'u_gender',$extra);
}

function us_state_dropdown($selected,$extra) {
 	global $arr_us_state;
	return array_dropdown($arr_us_state, $selected, 'u_state' , $extra);
}
function  incentive_type_dropdown($sel_value,$name,$extra){
// 	( $arr, $sel_value='', $name='', $extra='', $choose_one='', $arr_skip= array())
	global $ARR_PAYMENT_TYPE2;
	return array_dropdown($ARR_PAYMENT_TYPE2, $sel_value, $name,$extra);
}
	
function  payment_type_dropdown($sel_value,$name,$extra){
// 	( $arr, $sel_value='', $name='', $extra='', $choose_one='', $arr_skip= array())
	global $ARR_PAYMENT_TYPE;
	return array_dropdown($ARR_PAYMENT_TYPE, $sel_value, $name,$extra);
}
function traxrate_dropdown($name,$sel_value){
	$arr = array( "Exempted" => 'Exempted', '4' => '4%', '12.5' => '12.5%','1' => '1%');
	return array_dropdown($arr, $sel_value, $name);
}

function taxable_dropdown($name,$sel_value){
	$arr = array( "taxable" => 'Taxable', 'nontaxable' => 'Non Taxable');
	return array_dropdown($arr, $sel_value, $name);
}

function guardian_dropdown($name,$sel_value){
	$arr = array( "father" => 'Father', 'husband' => 'Husband', 'other' => 'Other');
	return array_dropdown($arr, $sel_value, $name);
}

function status_dropdown($name ,$sel_value ){
	$arr = array( "" => 'Please Select ','Banned' => 'Block ID\'s','Active' => 'Active', 'Inactive' => 'Inactive');
	return array_dropdown($arr, $sel_value, $name);
}

function yes_no_dropdown($name,$sel_value){
	$arr = array( "yes" => 'Yes', 'no' => 'No');
	return array_dropdown($arr, $sel_value, $name);
}
function join_mode_dropdown($name,$sel_value,$extra){
	$arr = array(''=>'Please select', 'Direct' => 'Direct', 'Spill' => 'Spill');
	return array_dropdown($arr, $sel_value, $name,$extra);
}

function left_right_dropdown($name,$sel_value,$extra){
	$arr = array( ''=>'Please select','A' => 'Left', 'B' => 'Right');
	return array_dropdown($arr, $sel_value, $name,$extra);
}
function u_gender_dropdown($selected,$extra) {
  	
	$arr_gender = array( "male" => 'Male', 'female' => 'Female');
	return array_dropdown($arr_gender,$selected,'u_gender',$extra);
}
 						
function package_dropdown($sel_value,$extra){
	$sql ="select utype_id , utype_name from ngo_users_type where utype_status='Active'  order by utype_id";  
	return make_dropdown($sql, 'package', $sel_value,  'class="txtbox" alt="select"  style="width:255px;"','Please select');
 }

function week_dropdown($sel_value,$extra){
 	global $ARR_WEEK;
	return array_dropdown($ARR_WEEK, $sel_value, 'dia_day',$extra);
}

function weekday_dropdown($sel_value,$extra){
 	global $ARR_WEEK_DAYS;
	return array_dropdown($ARR_WEEK_DAYS, $sel_value, 'dia_week',$extra);
}


function cal_days($dateFrom,$dateto){
 	$dateFrom = date("d-m-Y H:i:s",strtotime($dateFrom));
	$dateTo = date("d-m-Y H:i:s", strtotime($dateto));
	$diffd = getDateDifference($dateFrom, $dateTo, 'd');
	$diffh = getDateDifference($dateFrom, $dateTo, 'h');
	$diffm = getDateDifference($dateFrom, $dateTo, 'm');
	$diffs = getDateDifference($dateFrom, $dateTo, 's');
	$diffa = getDateDifference($dateFrom, $dateTo, 'a');
 	return $diffd+0;
 } 
   
function cal_lastlogin($dateFrom){
#sb-- calculate login time in hrs and days   	
	#$dateFrom = "07-11-2006 06:00:00";
	$dateFrom = date("d-m-Y H:i:s",strtotime($dateFrom));
	$dateTo = date("d-m-Y H:i:s", strtotime('now'));
	$diffd = getDateDifference($dateFrom, $dateTo, 'd');
	$diffh = getDateDifference($dateFrom, $dateTo, 'h');
	$diffm = getDateDifference($dateFrom, $dateTo, 'm');
	$diffs = getDateDifference($dateFrom, $dateTo, 's');
	$diffa = getDateDifference($dateFrom, $dateTo, 'a');
	
	if ($diffd <=1) {
		if ($diffh<=1) { $logintext = 'Online Now';} 
		else { 	$logintext = 'Offline';}
	} else {
		$logintext = 'Offline';	 
	}
	return $logintext;
	/*
	echo 'Calculating difference between ' . $dateFrom . ' and ' . $dateTo . ' <br /><br />';
	echo $diffd . ' days.<br />';
	echo $diffh . ' hours.<br />';
	echo $diffm . ' minutes.<br />';
	echo $diffs . ' seconds.<br />';
	echo '<br />In other words, the difference is ' . $diffa['days'] . ' days, ' . $diffa['hours'] . ' hours, ' . $diffa['minutes'] . ' minutes and ' . $diffa['seconds'] . ' seconds.
	';
*/
}

function getDateDifference($dateFrom, $dateTo, $unit = 'd') {
	$difference = null;
	$dateFromElements = split(' ', $dateFrom);
	$dateToElements = split(' ', $dateTo);
	$dateFromDateElements = split('-', $dateFromElements[0]);
	$dateFromTimeElements = split(':', $dateFromElements[1]);
	$dateToDateElements = split('-', $dateToElements[0]);
	$dateToTimeElements = split(':', $dateToElements[1]);
	// Get unix timestamp for both dates
	$date1 = mktime($dateFromTimeElements[0], $dateFromTimeElements[1], $dateFromTimeElements[2], $dateFromDateElements[1], $dateFromDateElements[0], $dateFromDateElements[2]);
	$date2 = mktime($dateToTimeElements[0], $dateToTimeElements[1], $dateToTimeElements[2], $dateToDateElements[1], $dateToDateElements[0], $dateToDateElements[2]);
	if( $date1 > $date2 )
	{
		return null;
	}
	$diff = $date2 - $date1;
	$days = 0;
	$hours = 0;
	$minutes = 0;
	$seconds = 0;
	if ($diff % 86400 <= 0)  // there are 86,400 seconds in a day
	{
		$days = $diff / 86400;
	}
	if($diff % 86400 > 0)
	{
		$rest = ($diff % 86400);
		$days = ($diff - $rest) / 86400;
		if( $rest % 3600 > 0 )
		{
			$rest1 = ($rest % 3600);
			$hours = ($rest - $rest1) / 3600;
			if( $rest1 % 60 > 0 )
			{
				$rest2 = ($rest1 % 60);
				$minutes = ($rest1 - $rest2) / 60;
				$seconds = $rest2;
			}
			else
			{
				$minutes = $rest1 / 60;
			}
		}
		else
		{
		$hours = $rest / 3600;
		}
	}
	switch($unit)
	{
	case 'd':
	case 'D':
		$partialDays = 0;
		$partialDays += ($seconds / 86400);
		$partialDays += ($minutes / 1440);
		$partialDays += ($hours / 24);
		$difference = $days + $partialDays;
		break;
	case 'h':
	case 'H':
		$partialHours = 0;
		$partialHours += ($seconds / 3600);
		$partialHours += ($minutes / 60);
		$difference = $hours + ($days * 24) + $partialHours;
		break;
	case 'm':
	case 'M':
		$partialMinutes = 0;
		$partialMinutes += ($seconds / 60);
		$difference = $minutes + ($days * 1440) + ($hours * 60) + $partialMinutes;
		break;
	case 's':
	case 'S':
		$difference = $seconds + ($days * 86400) + ($hours * 3600) + ($minutes * 60);
		break;
	case 'a':
	case 'A':
	$difference = array (
	"days" => $days,
	"hours" => $hours,
	"minutes" => $minutes,
	"seconds" => $seconds
	);
	break;
	}
	return $difference;
}

function pacific_date2(){
	//Monday, November 06, 2006 
	$pst_date = gmdate("Y-m-d", mktime(date("H")-0, date("i"), date("s"), date("m"), date("d"), date("Y")));
	return $pst_date;
}
function pacific_time2(){
//10:44:39 PM 
	$pst_time = gmdate("H:i:s A", mktime(date("H")-12, date("i"), date("s"), date("m"), date("d"), date("Y")));
	return $pst_time;
}


function pacific_time(){
//10:44:39 PM 
	$pst_time = gmdate("H:i:s A", mktime(date("H")-8, date("i"), date("s"), date("m"), date("d"), date("Y")));
	return $pst_time;
}
 
function pacific_date(){
	//Monday, November 06, 2006 
	$pst_date = gmdate("l F m Y", mktime(date("H")-8, date("i"), date("s"), date("m"), date("d"), date("Y")));
	return $pst_date;
} 
 


function smile($content){
	//global $arr_smile;
	$sql_smile	= "select * from ngo_smilies";
	$res_sql_smile=db_query($sql_smile); 
	if(mysqli_num_rows($res_sql_smile)>0){
	 $arr_smile	=	array();
	 while($row_smile=mysqli_fetch_array($res_sql_smile)){
		@extract($row_smile);
	 	$arr_smile[$smile_url]	=	$code;		
	 }
	}
	if(is_array($arr_smile)){
		foreach($arr_smile as $key=>$value){
			if(strpos($content,$value)!=-1){
				$content	=	str_replace($value,'<img src="'.SITE_WS_PATH.'/images/smiles/'.$key.'" border=0>',$content);
			 }
		}
	}
	
	return $content;
}

function rating($table_name,$column_name,$id,$column_rating) {
  $sql_rating = "select avg($column_rating) from $table_name where $column_name='$id'";
  $result_rating=db_scalar($sql_rating);
 return ceil($result_rating);
}

function banner($page,$width,$count,$rand='rand')
 {
  if($rand){
  $query="select * from ngo_banner where banner_page = '$page' and  banner_start_date <= curdate() and banner_end_date >= curdate() and banner_status='Active' order by rand() limit $count";
 
  } else {
  $query="select * from ngo_banner where banner_page = '$page' and banner_start_date <= curdate() and banner_end_date >= curdate() and banner_status='Active' order by banner_id limit $count";
 
  }
//echo $query;

  $result=db_query($query);
  if($result){
	  while($res=mysqli_fetch_array($result))
	   { 
	  if($res['banner_name']){
			if($res['banner_link']){
			$str="<a href=".$res['banner_link']." target='_blank'><img src=".UP_FILES_WS_PATH.'/banner/'.$res['banner_name']." align='center' style='margin-right:5px;' class='border_image'/></a>";
	       } else {
	  		$str="<img src=".UP_FILES_WS_PATH.'/banner/'.$res['banner_name']." align='center' style='margin-right:5px;' class='border_image'/>";
	   		  }
   } else {
	    if($res['banner_link']){
	  	$str="<a href=".$res['banner_link']." target='_blank'>".$res['banner_text']."</a>";
        } else {
		$str=$res['banner_text'];
        }   
      }
	  $str2[]=$str;
	} 
   return $str2;
 }
}






function convert_number($number) 
{ 
    if (($number < 0) || ($number > 999999999)) 
    { 
    throw new Exception("Number is out of range");
    } 

    $Gn = floor($number / 1000000);  /* Millions (giga) */ 
    $number -= $Gn * 1000000; 
    $kn = floor($number / 1000);     /* Thousands (kilo) */ 
    $number -= $kn * 1000; 
    $Hn = floor($number / 100);      /* Hundreds (hecto) */ 
    $number -= $Hn * 100; 
    $Dn = floor($number / 10);       /* Tens (deca) */ 
    $n = $number % 10;               /* Ones */ 

    $res = ""; 

    if ($Gn) 
    { 
        $res .= convert_number($Gn) . " Million"; 
    } 

    if ($kn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($kn) . " Thousand"; 
    } 

    if ($Hn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($Hn) . " Hundred"; 
    } 

    $ones = array("", "One", "Two", "Three", "Four", "Five", "Six", 
        "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", 
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", 
        "Nineteen"); 
    $tens = array("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", 
        "Seventy", "Eigthy", "Ninety"); 

    if ($Dn || $n) 
    { 
        if (!empty($res)) 
        { 
            $res .= " and "; 
        } 

        if ($Dn < 2) 
        { 
            $res .= $ones[$Dn * 10 + $n]; 
        } 
        else 
        { 
            $res .= $tens[$Dn]; 

            if ($n) 
            { 
                $res .= "-" . $ones[$n]; 
            } 
        } 
    } 

    if (empty($res)) 
    { 
        $res = "zero"; 
    } 

    return $res; 
} 


// $current_cat_id: the current category id number
 // $count: just a counter, call it as 0 in your function call and forget about it
 /* GET THE DROP DOWN LIST OF CATEGORIES */
function get_cat_selectlist($current_cat_id, $count,$upto_level) {
 	 static $option_results;
	 // if there is no current category id set, start off at the top level (zero)
	 if (!isset($current_cat_id)) {
		 $current_cat_id =0;
	 }
	 // increment the counter by 1
	 $count = $count+1;
	 // query the database for the sub-categories of whatever the parent category is
	 $sql =  'SELECT cat_id, cat_name from ngo_products_cat where cat_status="Active" and cat_parentid =  '.$current_cat_id;
	 $sql .=  ' order by cat_name asc ';
 	 $get_options = db_query($sql);
	 $num_options = mysqli_num_rows($get_options);
 	 // our category is apparently valid, so go ahead ��
	 if ($num_options > 0) {
	 while (list($cat_id, $cat_name) = mysqli_fetch_row($get_options)) {
 	 // if its not a top-level category, indent it to
	 //show that its a child category
		 
		 if ($current_cat_id!=0) {
			 $indent_flag = '&nbsp;&nbsp;';
			 for ($x=2; $x<=$count; $x++) {
			 	$indent_flag .=  ' - ';
			 }
		 }
		// check category level
		if ($upto_level>=$count || $upto_level==0 ) { 
			 $cat_name = $indent_flag.$cat_name;
			 $option_results[$cat_id] = $cat_name; 
		}
		 // print "<br> = $cat_id , $count ,$upto_level  ";
		 // now call the function again, to recurse through the child categories
		 get_cat_selectlist($cat_id, $count,$upto_level );
		 }
	 }
 	 
	 return $option_results;
 }

//  upto_level is for selecting caretegory level 1st leve, 2nd level, or how defth
function get_product_cat($name,$sub_parentid ,$upto_level) {

 echo '<select name="'.$name.'" class="txtbox">';
 	echo '<option value="">-- Select Product Category-- </option>';
	$get_options = get_cat_selectlist(0, 0,$upto_level);
	if (count($get_options) > 0){
	 //$categories = $sub_parentid;
	 foreach ($get_options as $key => $value) {
		 $options .="<option value=\"$key\"";
		 // show the selected items as selected in the listbox
		 if ($sub_parentid  == "$key") {
			 $options .=" selected=\"selected\"";
		 }
		 $options .=">$value</option>\n";
	 }
	}
	echo $options;
  echo '</select>'; 
}


function u_join_mode_dropdown($name,$sel_value){
	$arr = array('' => 'Please Select', 'General' => 'General', 'Affiliate' => 'Affiliate');
	return array_dropdown($arr, $sel_value, $name);
} 





?>
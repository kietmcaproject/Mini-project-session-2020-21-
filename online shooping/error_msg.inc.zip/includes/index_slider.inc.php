  <!-- hook slideshow -->
          <div  id="pts-slideshow" class="slideshow">
            <div class="bannercontainer banner-fullwidth hidden-sp" style="padding: 0 0;margin: 0px;background-color:#171717">
              <div id="sliderlayer18421146" class="rev_slider fullwidthbanner" style="width:100%;height:467px; " >
                <ul>
 <?
 			//$news_place = db_scalar("select u_group from ngo_users where  u_username ='$username'  limit 0,1"); 
  			$sql_main_banner= "select  * from  ngo_slide where slide_status='Active' and slide_category='MAIN_BANNER' order by slide_id desc  ";
			$sql_main_banner .= "limit 0,10 ";
			$result_main_banner = db_query($sql_main_banner);
			$ctr_main_banner=0;
			while($line_main_banner=  (mysqli_fetch_array($result_main_banner)))	{
			$ctr_main_banner++;
			@extract($line_main_banner);
 			?>
		 
			<? if (($slide_image!='')&& (file_exists(UP_FILES_FS_PATH.'/slide/'.$slide_image))) {  ?>
			 
			<li   data-masterspeed="300"  data-transition="random" data-slotamount="7" data-thumb="<?=show_thumb(UP_FILES_WS_PATH.'/slide/'.$slide_image,753,290,'resize')?>"><a href="<?=$line_main_banner['slide_page_link']?>"> <img src="<?=UP_FILES_WS_PATH.'/slide/'.$slide_image?>" alt="<?=$line_right['slide_title']?>" title="<?=$line_right['slide_title']?>" style="width:865px; height:347px;"  />
			</a>
			</li>
		 
 			    
 			  <? }  ?>
			
			<? } ?>
				
<!--
 <li   data-masterspeed="300"  data-transition="random" data-slotamount="7" data-thumb="images/slider/slider-02.jpg" style="background-color:#171717"><img src="images/slider/slider-02.jpg" alt=""/></li>
 <li   data-masterspeed="300"  data-transition="random" data-slotamount="7" data-thumb="images/slider/slider-03.jpg"> <img src="images/slider/slider-03.jpg" alt=""/></li>-->
                </ul>
                <div class="tp-bannertimer tp-top"></div>
              </div>
            </div>
            <script type="text/javascript">
             
                 var tpj=jQuery;
                 
                 if (tpj.fn.cssOriginal!=undefined)
                 tpj.fn.css = tpj.fn.cssOriginal;

                 tpj("#sliderlayer18421146").revolution(
                 {
                     delay:8000,
                 startheight:467,
                 startwidth:1170,


                 hideThumbs:0,

                 thumbWidth:87,                     
                 thumbHeight:50,
                 thumbAmount:3,
                                  navigationType:"none",
                                  navigationArrows:"verticalcentered",                
                                  navigationStyle:"round",          
                 
                 navOffsetHorizontal:0,
				                  navOffsetVertical:20,  
					
                 touchenabled:"on",         
                 onHoverStop:"on",                     
                 shuffle:"on",  
                 stopAtSlide: -1,                        
                 stopAfterLoops:-1,                     

                 hideCaptionAtLimit:0,              
                 hideAllCaptionAtLilmit:0,              
                 hideSliderAtLimit:0,           
                 fullWidth:"on",
                 shadow:0
                 });
                 $( document ).ready(function() {
                    $('.caption',$('#sliderlayer18421146')).click(function(){
                        if($(this).data('link') != undefined && $(this).data('link') != '') location.href = $(this).data('link');
                    });
                 });
             
</script>
          </div>
          <!-- end slideshow -->
 <header class="header-style-1"> 
  
  <!-- ============================================== TOP MENU ============================================== -->
  <div class="top-bar animate-dropdown">
    <div class="container">
      <div class="header-top-inner">
        <div class="cnt-account">
          <ul class="list-unstyled">
		  <li><a href="index.php"><i class="icon fa fa-home"></i>Home</a></li>
            
			<li><a href="contact_us.php"><i class="icon fa fa-phone"></i>Contact Us</a></li>
             
			 <? if ($_SESSION['sess_uid']=='') { ?>
           
			<li><a href="registration.php"><i class="icon fa fa-user"></i>Create An Account</a></li>
			 <li><a href="login.php"><i class="icon fa fa-lock"></i>Login</a></li>
			 <?  } else { ?>
			 
			 <li><a href="myaccount.php"><i class="icon fa fa-home"></i>Dashboard</a></li>
			<li><a href="logout.php"><i class="icon fa fa-sign-out"></i>Logout</a></li>
			 <?  }  ?>
          </ul>
        </div>
        <!-- /.cnt-account -->
        
      
        <!-- /.cnt-cart -->
        <div class="clearfix"></div>
      </div>
      <!-- /.header-top-inner --> 
    </div>
    <!-- /.container --> 
  </div>
  <!-- /.header-top --> 
  <!-- ============================================== TOP MENU : END ============================================== -->
  <div class="main-header">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-3 logo-holder"> 
          <!-- ============================================================= LOGO ============================================================= -->
          <div class="logo"> <a href="index.php"> <img src="assets/images/logo.png" alt="logo"> </a> </div>
          <!-- /.logo --> 
          <!-- ============================================================= LOGO : END ============================================================= --> </div>
        <!-- /.logo-holder -->
        
        <div class="col-xs-12 col-sm-12 col-md-7 top-search-holder"> 
          <!-- /.contact-row --> 
          <!-- ============================================================= SEARCH AREA ============================================================= -->
          <div class="search-area">
            <form>
              <div class="control-group">
                 
                <input class="search-field" placeholder="Search here..." />
                <a class="search-button" href="#" ></a> </div>
            </form>
          </div>
          <!-- /.search-area --> 
        
        
         
        <!-- /.top-cart-row --> 
      </div>
      <!-- /.row --> 
      
    </div>
    <!-- /.container --> 
    
  </div>
  <!-- /.main-header --> 
  
  <!-- ============================================== NAVBAR ============================================== -->
  <div class="header-nav animate-dropdown">
    <div class="container">
      <div class="yamm navbar navbar-default" role="navigation">
        <div class="navbar-header">
       <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> 
       <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div class="nav-bg-class">
          <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
            <div class="nav-outer">
			 
              <ul class="nav navbar-nav">
                <li  class="active dropdown yamm-fw"> <a href="index.php"  >Home</a> </li>
				
				 <li  > <a href="#"  >About Us </a> </li>
				 
				  <li > <a href="contact_us.php"  >Contact Us</a> </li>
				  
				  <li  > <a href="login.php"  >Sign In</a> </li>
				  
				  <li> <a href="registration.php"  >Sign Up</a> </li>
                  
                 
				
       
				 
				 
               
                
 				  
                <li class="dropdown  navbar-right special-menu"> <a href="#">Welcome visitor!</a> </li>
				 
				  
			 
				 
				 
				 
              </ul>
			   
              <!-- /.navbar-nav -->
              <div class="clearfix"></div>
            </div>
            <!-- /.nav-outer --> 
          </div>
          <!-- /.navbar-collapse --> 
          
        </div>
        <!-- /.nav-bg-class --> 
      </div>
      <!-- /.navbar-default --> 
    </div>
    <!-- /.container-class --> 
    
  </div>
  <!-- /.header-nav --> 
  <!-- ============================================== NAVBAR : END ============================================== --> 
  
</header>
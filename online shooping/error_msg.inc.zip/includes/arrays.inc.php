<?
$ARR_VALID_IMG_EXTS = array('jpg', 'jpeg', 'jpe', 'gif', 'png', 'bmp');

$ARR_WEEK_DAYS = array(
'mon' => 'Monday',
'tue' => 'Tuesday',
'wed' => 'Wednesday',
'thu' => 'Thursday',
'fri' => 'Friday',
'sat' => 'Saturday',
'sun' => 'Sunday'
);

$ARR_WEEK = array(
'Wk1' => 'Week I',
'Wk2' => 'Week II',
'Wk3' => 'Week III',
'Wk4' => 'Week IV',
'Wk5' => 'Week V'
);

$ARR_MONTHS = Array('01'=>'Jan' , '02'=>'Feb' , '03'=>'Mar' , '04'=>'Apr' , '05'=>'May' , '06'=>'Jun' , '07'=>'Jul' , '08'=>'Aug' , '09'=>'Sep' , '10'=>'Oct' , '11'=>'Nov' , '12'=>'Dec');

$ARR_POSSITION = array( ''=>'Please select','A' => 'Left', 'B' => 'Right');


if ($handle = opendir(dirname(__FILE__).'/db_arrays')) { 
	while (false !== ($file = readdir($handle))) { 
		if ($file != "." && $file != "..") { 
			include(dirname(__FILE__).'/db_arrays/'.$file);
		} 
	} 
   closedir($handle); 
} 
$ARR_RECHARGE_GROUP = array(''=>'Please Select','MOB'=>'Mobile','DTH'=>'DTH','DC'=>'Data Card' );
$ARR_VERIFIED_STATUS = array( ''=>'Please select','Verified' => 'Verified', 'Not Verified' => 'Not Verified');
$ARR_DEDUCTION_TYPE = array('TDS'=>'TDS','OtherDeduction'=>'OtherDeduction');
$ARR_GENDER = array('0'=>'Please select','Male'=>'Male','Female'=>'Female');
$ARR_PERMISSION = array('public'=>'Public','private'=>'Private');
$ARR_RATE = array('1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10');
//
$ARR_PLAN_TYPE = array(''=>'Please Select','TOPUP'=>'TOPUP','RECHARGE'=>'RECHARGE');
$ARR_OPEN_CLOSE = array( '0'=>'Close','1' => 'Open');

$ARR_USER_GROUP = array('' => 'Please Select', '1' => 'Users',  '2' => 'Franchise');

$ARR_PAYMENT_PROCESSOR = array(''=>'Please Select','PM'=>'Perfect Money','PAYPAL'=>'Paypal','BW'=>'Bank Wire');
$ARR_PAYMENT_GROUP = array('' => 'Please Select', 'ROI' => 'ROI','WORKING' => 'Working');
///OLD $ARR_WALLET_GROUP = array('' => 'Please Select', 'SW' => 'Shopping ','SMS' => 'Bulk SMS','RECH' => 'Recharge');
$ARR_WALLET_GROUP = array(''=>'Please Select' ,'EW'=>'eWallet','SW'=>'Shopping Wallet' );
/*,'CW' => 'Cash'*/

//Executive', 'Taxi', 'Advertiser', 'Qscreen
//,'Taxi'=>'Taxi','Advertiser'=>'Advertiser','Qscreen'=>'Qscreen Holder'
$ARR_ACCOUNT_TYPE = array(''=>'Please Select','Executive'=>'Executive');
//,'PAYZA'=>'Payza' ,'LR'=>'Liberty Reserve' ,'EP'=>'Ego Pay'
//,'ROI'=>'ROI','LEADERSHIP1'=>'LEADERSHIP1','LEADERSHIP2'=>'LEADERSHIP2','LEADERSHIP3'=>'LEADERSHIP3','JOINING_FEES'=>'JOINING FEES','TOPUP_FEES'=>'TOPUP FEES'
$ARR_PAYMENT_TYPE = array(''=>'Please Select','FIRST_ORDER_INCENTIVE'=>'First Order Incentive','REPURCHASE_INCENTIVE'=>'Repurchase Incentive','UNI_LVEEL_INCENTIVE'=>'Uni Level Incentive','ROYALTY_INCENTIVE'=>'Royalty Incentive','BANK_WITHDRAW'=>'Fund Withdrawal', 'DEDUCTION'=>'Deduction');


$ARR_PAYMENT_TYPE2 = array(''=>'All Incentive','FIRST_ORDER_INCENTIVE'=>'First Order Incentive','REPURCHASE_INCENTIVE'=>'Repurchase Incentive','UNI_LVEEL_INCENTIVE'=>'Uni Level Incentive','ROYALTY_INCENTIVE'=>'Royalty Incentive');
 // ,'2'=>'Send SMS','3'=>'Send SMS Other Number'
 
 $ARR_ADMIN_LINK_PERMISSION= array('1'=>'Manage User' ,'2'=>'Manage Available Pin' ,'3'=>'Manage Used Pin','4'=>'Manage Topup List','5'=>'Manage Payment','6'=>'Manage User E-Wallet','7'=>'Products Category' ,'8'=>'Manage Products','9'=>'Manage admin','10'=>'Good Morning SMS','11'=>'Promo SMS','12'=>'Support Ticket List','13'=>'Manage News' ,'14'=>'Manage Static Pages' ,'15'=>'Feedback Closing List' ,'16'=>'Feedback Videos List' ,'17'=>'Feedback History List' ,'18'=>'Contact Us List' );
 
  $ARR_ADMIN_PAGES=array('1'=>'users_list.php','2'=>'code_list.php' ,'3'=>'used_code_list.php','4'=>'recharge_topup_list.php','5'=>'users_acc_drcr_list.php','6'=>'users_ewallet_list.php','7'=>'product_cate_list.php' ,'8'=>'products_list.php','9'=>'admin_list.php','10'=>'send_sms.php','11'=>'send_sms_other.php','12'=>'complain_list.php','13'=>'news_list.php','14'=>'staticpage_list.php','15'=>'closing_list.php','16'=>'browsing_list.php','17'=>'browsing_history_list.php','18'=>'contact_us_list.php');

 
$ARR_SECURITY_QST = array('1'=>'In what city or town did your mother and father meet?','2'=>'What is your oldest brother\'s birthday month and year?','3'=>'What is your spouse or partner\'s mother\'s maiden name?','4'=>'In what city or town was your first job?','5'=>'What is the name of the company of your first job?','6'=>'What is the country of your ultimate dream vacation?','7'=>'What is your mother\'s middle name?','8'=>'What is your grandmother\'s first name?','9'=>'In what city and country do you want to retire?');

/*

, '4'=>'Manage Cheque'
,'4'=>'cheque_list.php'

 $ARR_ADMIN_LINK_PERMISSION=	array('0'=>'Manage User','1'=>'Manage Closing' , '2'=>'Manage Payout','3'=>'Manage Setting','4'=>'Send SMS','5'=>'Send SMS Other Number', '6'=>'Manage Bill', '7'=>'Manage Ledger', '8'=>'Manage Cheque', '9'=>'Manage Pin','10'=>'Manage Static Pages','11'=>'Manage admin','12'=>'Manage User','13'=>'Manage Product Distribution','14'=>'Manage Pin Request' ,'15'=>'Feedback', '15'=>'Manage Payout Deduction ', '16'=>'Manage 21 Days Offer ');
 
 $ARR_ADMIN_PAGES=array('0'=>'users_list.php','1'=>'closing_list.php' , '2'=>'payout_cheque_list.php','3'=>'setting_list.php','4'=>'send_sms.php','5'=>'send_sms_other.php', '6'=>'bill_list.php', '7'=>'ledger_list.php', '8'=>'cheque_list.php','9'=>'code_list.php','10'=>'staticpage_list.php','11'=>'admin_list.php' ,'12'=>'users_list.php','13'=>'product_dist_list.php','14'=>'code_req_list.php','15'=>'feedback_list.php', '15'=>'deduction_list.php','16'=>'generate_payout_all.php');
*/
 
$META_TITLE=SITE_NAME;
$META_KEYWORD='';
$META_DESC='';

?>
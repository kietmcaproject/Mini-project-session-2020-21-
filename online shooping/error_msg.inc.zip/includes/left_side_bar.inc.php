<div id="right_column" class="sidebar column col-xs-12 col-sm-12 col-md-3 col-md-3  offcanvas-sidebar" style="margin-left: -5px;">
 <!-- MODULE Block advertising -->
 <? if($page=='index') { ?>
 
  <?
 			//$news_place = db_scalar("select u_group from ngo_users where  u_username ='$username'  limit 0,1"); 
  			$sql_left_banner= "select  * from  ngo_slide where slide_status='Active' and slide_category='LEFT_ADVERTISEMENT' order by slide_id desc  ";
			$sql_left_banner .= "limit 0,3 ";
			$result_left_banner = db_query($sql_left_banner);
			$ctr_left_banner=0;
			while($line_left_banner=  (mysqli_fetch_array($result_left_banner)))	{
			$ctr_left_banner++;
			@extract($line_left_banner);
 			?>
		 
			<? if (($slide_image!='')&& (file_exists(UP_FILES_FS_PATH.'/slide/'.$slide_image))) {  ?>
			
			 <div class="advertising_block block"> <a href="<?=$line_left_banner['slide_page_link']?>" target="_self" title="<?=$line_left_banner['slide_title']?>"><img class="img-responsive" src="<?=(UP_FILES_WS_PATH.'/slide/'.$slide_image)?>" alt="<?=$line_left_banner['slide_title']?>" title="<?=$line_left_banner['slide_title']?>" style="width:278px; height:165px;"  /></a> </div> 
			     
 			  <? }  ?>
			
			<? } ?>
 
 
 
 
 
 
 
 
 
 
 
          <!-- <div class="advertising_block block"> <a href="#" title="Open kart"><img class="img-responsive" src="images/advertising-01.jpg" alt="" title="" /></a> </div> 
		    <div class="advertising_block block"> <a href="#" title="Open kart"><img class="img-responsive" src="images/advertising-02.jpg" alt="" title="" /></a> </div> 
			 <div class="advertising_block block"> <a href="#" title="Open kart"><img class="img-responsive" src="images/advertising-03.jpg" alt="" title="" /></a> </div> -->
  <? } ?>   
  
  
  
  
  
  
  
        
          <div id="ptsproductcountdown" class="block products_block ptsproductcountdown highlighted block-danger nopadding" style="margin-top:15px;   ">
            <h4 class="title_block"><span>Hot Deal</span></h4>
            <div class="block_content" >
              <div id="ptsproductcountdown_left" class="boxcarousel carousel slide">
                <div class="carousel-controls"> <a class="carousel-control left" href="#ptsproductcountdown_left"   data-slide="prev">&lsaquo;</a> <a class="carousel-control right" href="#ptsproductcountdown_left"  data-slide="next">&rsaquo;</a> </div>
                <div class="carousel-inner" style="overflow:hidden;">
				
						 <? 
								$sql_hot_prod= "select  * from ngo_products where prod_status='Active'  and prod_featured='featured'   order by prod_id desc  ";
								$sql_hot_prod .= "limit 0,15 ";
								$result_hot_prod = db_query($sql_hot_prod);
								$ctr_hot_prod = 1;
								while($line_hot_prod=  (mysqli_fetch_array($result_hot_prod)))	{
								
								@extract($line_hot_prod);
						 
						?>	
				
                  <div class=" item <? if ($ctr_hot_prod=='1') { ?>active<? } ?>">
                    <ul class="products-block row"  >
                      <li class="col-xs-12 col-sm-12 col-md-12 col-lg-12 inactive ajax_block_product first_item" style=" height:293px;">
                         
						
						<!---->
						<div class="product-block  swap-gallery" itemscope itemtype="#">
                            <div class="product-container">
                              <div class="left-block">
                                <div class="product-image-container image"> 
								<a class="img product_img_link"	href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" title="<?=str_stop($prod_name,50)?>" itemprop="url">
								<? if (($line_hot_prod['prod_image']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line_hot_prod['prod_image']))) { 
				$ctr_skip++;
				?>
	 <img class="replace-2x img-responsive pts-image" src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line_hot_prod['prod_image'],310,272,'resize')?>" alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
             
              <? }  else { ?>
				<img class="replace-2x img-responsive pts-image" src="images/no_product_pic1.png"  alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
				<? }  ?>
								
		 					  </a> 
								  
								  
								   
                                  <meta itemprop="priceCurrency" content="USD" />
                                  <span class="product-label content_price_percent sale-percent-box" itemprop="offers" itemscope itemtype="#"> <!--<span class="price-percent-reduction sale-label">-15%</span>--> </span> <span class="product-label new-box"> <span class="new-label">New</span> </span>
                                  <div class="pts-atchover"> <a class="btn btn-default quick-view" title="Quick view" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="#"> <i class="icon-search-plus"></i> <span>Quick view</span> </a> </div>
                                </div>
                              </div>
                              <div class="right-block">
                                <div class="product-meta">
                                  <h4 class="name" itemprop="name"> <a class="product-name" href="#" title="<?=str_stop($prod_name,50)?> " itemprop="url" > <?=str_stop($prod_name,50)?> </a> </h4>
                                   
								   
							<? if ($_SESSION['sess_uid']=='') { ?><strong></strong>	   
								   
                        <div itemprop="offers" itemscope itemtype=" " class="content_price price"> <span itemprop="price" class="product-price">MRP. <?=$prod_mrp?> </span>
                                  <!--  <meta itemprop="priceCurrency" content="INR" />
                                    <span class="old-price product-price"> Rs.	<?=$prod_mrp?> </span> --></div>
									
							<? } else  { ?>		
								<div itemprop="offers" itemscope itemtype=" " class="content_price price"> <span itemprop="price" class="product-price">Offer Price. <?=$prod_price_retail?> </span>
                                  <!--  <meta itemprop="priceCurrency" content="INR" />
                                    <span class="old-price product-price"> Rs.	<?=$prod_mrp?> </span> --></div>	
							<?  } ?>		
									
									
                                 <?php /*?> <hr />
                                 
                                <a data-toggle="tooltip"   href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="nofollow" title="View Details" data-id-product="10"> 
							<i class=" icon-shopping-cart"></i>	<em>&nbsp;View Product's Details</em> </a> <?php */?>
								 
                                   
                                  
                                </div>
                              </div>
                            </div>
                            <!-- .product-container> -->
                          </div>
                      </li>
                    </ul>
                  </div>
				  
				  <? $ctr_hot_prod++; } ?>
				  
				  
				  
				 
				  
                 
				  
                </div>
              </div>
            </div>
          </div>
          <!-- /MODULE Block ptsproductcountdown -->
          <script type="text/javascript">
$(document).ready(function() {
    $('ptsproductcountdown').each(function(){
        $(this).carousel({
            pause: true,
            interval: 0
        });
    });
});
</script>
          <!-- MODULE Block blockleoblogstabs -->
          <?php /*?><div id="blockleoblogstabs" class="block blogs_block blockleoblogs nopadding">
            <h3 class="title_block blue"><span>Announcement</span></h3>
            <div class="block_content">
              <div id="blockleoblogs" class="carousel slide">
                 
                <div class="carousel-inner">
				
                  <div class="item active">
			<marquee  scrollamount="2"  direction="up" behavior="alternate" style=" height:265px;" >
				  
				  
			 <? 
				$sql_news_left= "select  * from  ngo_news where news_status='Active'";
				$sql_news_left .= "limit 0, 10 ";
				$result_news_left = db_query($sql_news_left);
				$ctr=1;
				while($line_news_left=  (mysqli_fetch_array($result_news_left)))	{
				@extract($line_news_left);
				 
			?>	
			
				  
				  
                    <div class="row">
                      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 blog_block ajax_block_blog first_item">
                        <div class="blog_container clearfix">
                          <div class="blog-image"> <a href="news_details.php?news_id=<?=$news_id?>" title="<?=$news_title?>">
						  
						   <?  if (($line_news_left[news_image]!='')&& (file_exists(UP_FILES_FS_PATH.'/news/'.$line_news_left[news_image]))) {  ?>
                        <img class="img-responsive" src="<?=show_thumb(UP_FILES_WS_PATH.'/news/'.$line_news_left[news_image],270,158,'resize')?>"   />
                        <? } else {  ?>	
						
						
						
						 <img src="images/news-1.jpg" alt="<?=$news_title?>" class="img-responsive"/>
						 <? } ?>
						 
						  </a> </div>
                        
                          <div class="blog-content">
                            <h5 class="blog-title"><a href="news_details.php?news_id=<?=$news_id?>" title="<?=$news_title?>"><?=str_stop($news_title , 100);?></a></h5>
                            <div class="blog-meta"> </div>
							   
                            <div class="blog-shortinfo">
                              <div class="blog-shortinfo" style="font-style:italic;"><?=str_stop($news_desc , 150);?><br />
Posted Date : <?=date_format2($news_datetime);?> </div>
							  
							   <div class="blog-shortinfo">  <a href="news_details.php?news_id=<?=$news_id?>" title="">Read More</a></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
					<? } ?>
                     
					 
					 </marquee>
                      
                  </div>
                   
                </div>
              </div>
            </div>
          </div><?php */?>
          <!-- /MODULE Block blockleoblogstabs -->
          <script type="text/javascript">
	$(document).ready(function() {
	    $('blockleoblogs').each(function(){
	        $(this).carousel({
	            pause: 'hover',
	            interval: 8000
	        });
	    });
	});
	</script>
          <!-- MODULE Block best sellers -->
          <div id="best-sellers_block_right" class="block block-danger nopadding products_block">
            <h4 class="title_block"> <span>Latest Products</span> </h4>
            <div class="block_content">
              <ul class="products products-block row">
			  	 <? 
								$sql_latest_prod= "select  * from ngo_products where prod_status='Active' and prod_show_hide_newproduct_cat='Show'  order by prod_id desc  ";
								$sql_latest_prod .= "limit 0,2 ";
								$result_latest_prod = db_query($sql_latest_prod);
								$ctr_latest_prod = 1;
								while($line_latest_prod=  (mysqli_fetch_array($result_latest_prod)))	{
								
								@extract($line_latest_prod);
						 
						?>	
                <li class="col-xs-12 col-sm-12 col-md-12 clearfix media" style="height:314px;">
                  <div class="product-block  swap-gallery" itemscope itemtype="#">
                            <div class="product-container">
                              <div class="left-block">
                                <div class="product-image-container image"> 
								<a class="img product_img_link"	href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" title="<?=str_stop($prod_name,50)?>" itemprop="url">
								<? if (($line_latest_prod['prod_image']!='')&& (file_exists(UP_FILES_FS_PATH.'/products/'.$line_latest_prod['prod_image']))) { 
				$ctr_skip++;
				?>
	 <img class="replace-2x img-responsive pts-image" src="<?=show_thumb(UP_FILES_WS_PATH.'/products/'.$line_latest_prod['prod_image'],310,272,'resize')?>" alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
             
              <? }  else { ?>
				<img class="replace-2x img-responsive pts-image" src="images/no_product_pic1.png"  alt="<?=str_stop($prod_name,50)?>" title="<?=str_stop($prod_name,50)?>" itemprop="image" />
				<? }  ?>
								
		 					  </a> 
								  
								  
								   
                                  <meta itemprop="priceCurrency" content="USD" />
                                  <span class="product-label content_price_percent sale-percent-box" itemprop="offers" itemscope itemtype="#"> <!--<span class="price-percent-reduction sale-label">-15%</span>--> </span> <span class="product-label new-box"> <span class="new-label">New</span> </span>
                                  <div class="pts-atchover"> <a class="btn btn-default quick-view" title="Quick view" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="#"> <i class="icon-search-plus"></i> <span>View</span> </a> </div>
                                </div>
                              </div>
                              <div class="right-block">
                                <div class="product-meta">
                                  <h4 class="name" itemprop="name" style="color:#FF0000; text-align:center;"> <a class="product-name" href="#" title="<?=str_stop($prod_name,50)?> " itemprop="url" > <?=str_stop($prod_name,50)?> </a> </h4>
                                    
                                  <? if ($_SESSION['sess_uid']=='') { ?>
								  <div itemprop="offers" itemscope itemtype=" " class="content_price price" style="text-align:center;"> <span itemprop="price" style="text-align:center;" class="product-price">MRP <?=$prod_mrp?> </span>
								  
								
                                   <!--  <meta itemprop="priceCurrency" content="INR" />
                                    <span class="old-price product-price"> Rs.	<?=$prod_mrp?> </span> --></div>
									
							  <? } else { ?>
								 <div itemprop="offers" itemscope itemtype=" " class="content_price price" style="text-align:center;"> <span itemprop="price" style="text-align:center;" class="product-price">Offer Price <?=$prod_price_retail?> </span>
								  
								
                                   <!--  <meta itemprop="priceCurrency" content="INR" />
                                    <span class="old-price product-price"> Rs.	<?=$prod_mrp?> </span> --></div> 
								  <?  } ?>		
									
									
									
                                 
                               <?php /*?> <hr /><div class=" ">
                                    <div style="width:170px; text-align:center;"><a data-toggle="tooltip" href="product_details.php?cat_id=<?=$prod_catid?>&prod_id=<?=$prod_id?>" rel="nofollow" title="View Details"  data-id-product="10"><i class=" icon-shopping-cart"></i><em>&nbsp;View Product's Details</em> </a></div>
								 
                                   
                                  </div><?php */?>  
                                
                                   
                                  
                                </div>
                              </div>
                            </div>
                            <!-- .product-container> -->
                          </div>
                </li>
				
				<? } ?> 
                 
              </ul>
            </div>
          </div>
          <!-- /MODULE Block best sellers -->
		 <!--  <div class="advertising_block block"> <a href="#" title="Open kart"><img class="img-responsive" src="images/advertising-04.jpg" style="height:350px;" alt="" title="" /></a> </div>-->
		   <? // if($page=='products') { ?>
         <!--  <div class="advertising_block block"> <a href="#" title="Open kart"><img class="img-responsive" src="images/advertising-05.jpg" alt="" title="" /></a> </div> -->
		    
  <? // } ?> 
        </div>   
	  
	  
	  
	
		 
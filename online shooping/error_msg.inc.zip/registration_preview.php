<?php
include ("includes/surya.dream.php");
$page='registration' ;
//protect_user_page();  
/*
 if ($_SESSION['sess_uid']!='') {
	header("location: myaccount.php");
	exit;
}*/
//print_r($_SESSION[POST]);

@extract($_SESSION[POST]);
$u_ip =  gethostbyaddr($_SERVER['REMOTE_ADDR']);
if(is_post_back()) {
 ///print_r($_POST);
 
   	    @extract ($_SESSION[POST]);
		$arr_error_msgs = array();
		// $total_ref = db_scalar("select count(u_id) from ngo_users where u_username = '$u_ref_userid'");
		$auto_id = db_scalar("select u_id from ngo_users where u_username = '$u_ref_userid'");
		$total_ref = db_scalar("select count(u_id) from ngo_users where u_id = '$auto_id'");
  	#	if ($u_ref_side =='') { $arr_error_msgs[] =  "Please select referer side";}
 		if ($total_ref ==0) { $arr_error_msgs[] =  "Referer ID  does not exist!";}
		
		// and code_useto>=ADDDATE(now(),INTERVAL 270 MINUTE)
		#$total_code = db_scalar("select count(code_id) from ngo_code where code_id = '$u_slno' and code_string='$u_code' and code_is='Available' and  code_cate='1' and code_status='Active'");
		#if ($total_code ==0) { $arr_error_msgs[] =  "Reference E-Pin SlNo or E-Pin Code does not exist or already used!";}
		$_SESSION['arr_error_msgs'] = $arr_error_msgs;
		//print_r($arr_error_msgs);
		if (count($arr_error_msgs) ==0) {
			#$u_ref_fname = db_scalar("select  u_fname from ngo_users where u_username = '$u_ref_userid'");
 			$u_ref_userid = db_scalar("select  u_id from ngo_users where u_username = '$u_ref_userid'");
  			$u_sponsor_id = get_sponsor_id($u_ref_userid,$u_ref_side);
 			$u_parent_id = db_scalar("select u_parent_id from ngo_users  order by u_id desc limit 0,1")+rand(10,20);
			//$u_username =  'A'.rand(1,9).$u_parent_id;
   			$u_guardian_name  = $u_guardian_title." ".$u_guardian_name;
			$dob = $year ."-". $month."-".$day;
			$u_password2 =  rand(100,999).rand(10,99);
  			$sql = "insert into ngo_users set  u_parent_id = '$u_parent_id',u_username='$u_username', u_password = '$u_password',u_password2 = '$u_password2', u_sponsor_id = '$u_sponsor_id', u_fname = '$u_fname', u_lname = '$u_lname', u_dob = '$u_dob', u_guardian='$u_guardian' ,u_guardian_name='$u_guardian_name' ,u_address = '$u_address' , u_city = '$u_city' , u_state = '$u_state', u_postalcode = '$u_postalcode', u_country = '$u_country',  u_email = '$u_email',u_phone = '$u_phone',u_mobile = '$u_mobile', u_nomi_name = '$u_nomi_name' , u_nomi_relation = '$u_nomi_relation' , u_sms_rate = '0.20', u_nomi_dob = '$u_nomi_dob' , u_nomi_address = '$u_nomi_address' ,u_ref_userid = '$u_ref_userid' ,u_ref_side='$u_ref_side' ,u_closeid='$u_closeid' , u_panno = '$u_panno', u_slno = '$u_slno' , u_code = '$u_code', u_admin = '$u_admin' ,u_status='Active' , u_bank_name='$u_bank_name', u_bank_acno='$u_bank_acno', u_bank_branch='$u_bank_branch' ,u_bank_ifsc_code='$u_bank_ifsc_code' ,u_bank_micr_code='$u_bank_micr_code' ,u_liberty_reserve='$u_liberty_reserve' , u_ok_pay='$u_ok_pay',u_perfect_money='$u_perfect_money' ,u_egopay='$u_egopay', u_alert_pay='$u_alert_pay' , u_security_ans='$u_security_ans', u_ip='$u_ip' ,u_date= ADDDATE(now(),INTERVAL 270 MINUTE),u_last_login=ADDDATE(now(),INTERVAL 270 MINUTE) ";
 			//$result = db_query($sql);
			$u_id = mysqli_insert_id();
 			$_SESSION[sess_recid] =$u_id ;
 			$_SESSION['sess_uid'] 		= $u_id;
			$_SESSION['sess_username'] 	= $u_username;
			$_SESSION['sess_email']		= $u_email;
			$_SESSION['sess_fname']		= $u_fname;
			$_SESSION['sess_date']		= $u_date;
 	 
// email


$message = "Dear ".$u_fname." Welcome To ".SITE_NAME." Your Login ID is ".$u_username." & Password is ".$u_password." & Txn Password :".$u_password2." For Details plz visit ".SITE_URL;
			print $msg= send_sms($u_mobile,$message); 
			exit;

		 
$message="
Hi ". $u_fname .", 

Today is a great day for kskmegamart and for you!

We're growing! Every three months we're doubling our user base. To accelerate this growth and acquire even more interesting plan, kskmegamart will, as of today, be operated by 'kskmegamart'.

Thank you for becoming a member of the ". SITE_NAME .".  

Visit us regularly to see what's new.

Your login information is provided below.  Please also keep in mind that you must finish your registration by clicking on the link below.

http://www.". SITE_URL ." 
Username = ". $u_username ."
Password = ". $u_password. "
E-Bank Password = ". $u_password. "
 

Once again, Thank you for being a part of ". SITE_NAME ."!

". SITE_NAME ."
http://www.". SITE_URL ."
";
 
  			$HEADERS  = "MIME-Version: 1.0 \n";
			$HEADERS .= "Content-type: text/plain; charset=iso-8859-1 \n";
			$HEADERS .= "From:  <".ADMIN_EMAIL.">\n";
			$SUBJECT  = SITE_NAME." Registration confirmation";
 			@mail($u_email, $SUBJECT, $message,$HEADERS);
  			$_SESSION[POST]='';

//
			 
 			//header("Location: payment_topup.php");
			header("Location: registration_conf.php");
			exit;
 
  	
  }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$META_TITLE?></title>
<?php include ("includes/extra_file.inc.php");?>
<?php include("includes/fvalidate.inc.php");?>
</head>

<body>
<!-- MAIN WRAPPER -->
<div id="container"> 
  
  <!-- SIDEFEATURES -->
  <div id="sidefeatures">
    <?php include ("includes/extra_file.php");?>
  </div>
  <!-- END OF SIDEFEATURES --> 
  
  <!-- HEADER -->
  <?php include ("includes/header.inc.php");?>
  <!-- END OF HEADER --> 
  
  <!-- CONTENT -->
  <div id="content_holder" class="fixed">
    <div class="inner">
      <div class="breadcrumb"> <a href="index.php">Home</a> » Registration </div>
      <h2 class="heading-title"><span>Registration</span></h2>
      
      <!-- LEFT COLUMN -->
         <?php include ("includes/left_file.php");?>
      <!-- END OF LEFT COLUMN -->
      
      <div id="content" class="content-column-left">
        <div class="content contacts-page">
          <div class="box-contacts fixed">
            <div class="box-content">
              <div class="stitched"></div>
			 <form name="registration" method="post" action="<?=$_SERVER['PHP_SELF']?>" enctype="multipart/form-data"  <?= validate_form()?> >
                          <table width="457" border="0" cellpadding="2" cellspacing="2"  >
                           
						     <tr>
                              
                              <td  valign="top" colspan="2"><!-- <textarea name="textfield" cols="55" rows="20"> </textarea>-->
							 <div >
							   
							  
							   <?=db_scalar("select static_desc from ngo_staticpage where static_page_name ='member_agreement' and static_status='Active' ");?></div>
							  </td>
                            </tr>
						    <tr>
                              <td align="right" class="maintxt"></td>
                              <td align="left" valign="top" ><input type="checkbox"  name="terms" id="terms" value="ON" alt="checkbox|0" emsg="Please accept terms and conditions">
                               <span class="blue"  > Agree with <?=SITE_URL?> Terms of service.</span> </td>
                            </tr>
                            
                          </table>
                      

              </div>
              <div class="stitched"></div>
            </div>
          </div>
          <div class="clear"></div>
          <div class="buttons">
            <div class="left">
			
			<a class="button" id="button-contact"><input name="Submit" type="submit" class="button" value="Submit" /></a></div>
			
          </div>
		  </form>
        </div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
  <!-- END OF CONTENT --> 
  
  <!-- PRE-FOOTER -->
  <div id="pre_footer">
    <div class="inner">

    </div>
  </div>
  <!-- END OF PRE-FOOTER --> 
  
  <!-- FOOTER -->
 <?php include ("includes/footer.inc.php");?>
</body>

<!-- Mirrored from metagraphics.eu/spicy/contact.html by HTTrack Website Copier/3.x [XR&CO'2010], Sat, 05 Oct 2013 07:27:28 GMT -->
</html>

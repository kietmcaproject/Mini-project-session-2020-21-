<?php
include ("includes/surya.dream.php");  
$page='registration' ;
//protect_user_page();

?>
 <!DOCTYPE html>
<html lang="en">
    <head>
		<?php include ("includes/extra_file.inc.php");?>
	 
		 
 	</head>
    <body class="cnt-home">
		<!-- ============================================== HEADER ============================================== -->
  <?php include ("includes/header.inc.php");?>
<!-- ============================================== HEADER : END ============================================== -->
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'>Registration Conformation</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
	<div class="container">
		<div class="my-wishlist-page width-50 centered">
			<div class="row">
 				<div class="col-md-12 my-wishlist  ">
	<div class="table-responsive">
   <? include("error_msg.inc.php");?> 
  			 <form name="registration" method="post" action="<?=$_SERVER['PHP_SELF']?>" enctype="application/x-www-form-urlencoded" <?= validate_form()?>>
			 <p class="tdhead" align="left" style="text-align:left; padding:10px;">&nbsp;Registration Confirmed</p>
                                <table width="100%" height="375" border="0" align="center" cellpadding="2" cellspacing="0" class=" ">
                                  <tr>
                                    <td width="1%" align="left" valign="top" >&nbsp;</td>
                                    <td width="99%" colspan="3" align="left" valign="top" ><!--<span class="error"> Registration complete successfully.</span>-->
                                      <? 
if ($u_id=='') {
	if ($_SESSION[sess_recid]!='') {$u_id=$_SESSION[sess_recid];} else {$u_id = $_SESSION[sess_uid];} 
}
								
$sql = "select * from ngo_users where  u_id ='$u_id'";
$result = db_query($sql);
$line= mysqli_fetch_array($result);
@extract($line);
							  ?>
                                      
                                     <p class=" ">Welcome to
                                              <?=SITE_NAME?>
                                              </p> 
                                      <p> 
                                        Thank you for joining. Kindly save your login details.
                                        </p>
                                      
										 <table width="100%" border="1" cellpadding="3" cellspacing="5" class="table table-bordered">
                                         <tr>
                                          <td width="33%" height="0" align="left"  >Your Name</td>
                                          <td width="1%" class=" "><strong>:</strong></td>
                                          <td width="66%" height="0" align="left" class=" "><?=$u_fname." ".$u_lname?> </td>
                                        </tr>
										<tr>
                                          <td width="33%" height="0" align="left" valign="top"  >Username</td>
                                          <td width="1%" class=" "><strong>:</strong></td>
                                          <td width="66%" height="0" align="left" class=" "><?=$u_username2?> </td>
                                        </tr>
                                        <tr>
                                          <td align="left" valign="top" class=" ">Password</td>
                                          <td ><strong>:</strong></td>
                                         <td   height="0" align="left"  ><?=$u_password?></td>
                                        </tr>
										<!-- <tr>
                                          <td   align="left" valign="top" class="maintxt"> Transaction Password </td>
                                          <td class="maintxt"><strong>:</strong></td>
                                         <td width="66%" height="0" align="left" class="txtbox"><?=$u_password2?></td>
                                        </tr> -->
                                         
                                      </table> 
                                      
                                        Thank-you for registration and welcome to
                                        <?=SITE_NAME?>
                                      </p>
                                       </td>
                                  </tr>
                                </table>
								
								</form>
   </div>
</div>			
 

</div><!-- /.row -->
		</div><!-- /.sigin-in-->
		<!-- ============================================== BRANDS CAROUSEL ============================================== -->
 <?php include ("includes/our_brand.inc.php");?><!-- /.logo-slider --><br>

<!-- ============================================== BRANDS CAROUSEL : END ============================================== -->	</div><!-- /.container -->
</div><!-- /.body-content -->
<!-- ============================================================= FOOTER ============================================================= -->
  <?php include ("includes/footer.inc.php");?>
<!-- ============================================================= FOOTER : END============================================================= -->
<?php include ("includes/extra_footer.inc.php");?>
	

</body>

</html>						  
			           

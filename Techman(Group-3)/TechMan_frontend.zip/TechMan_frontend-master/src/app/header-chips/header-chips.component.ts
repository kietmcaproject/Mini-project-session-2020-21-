import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-chips',
  templateUrl: './header-chips.component.html',
  styleUrls: ['./header-chips.component.css']
})
export class HeaderChipsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

package com.example.admincollegeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

public class UploadImage extends AppCompatActivity {

    private Spinner imageCategory;
    CardView selectImage;
    Button uploadImage;
    private ImageView galleryImageView;
    private  String category;

    private final int REQ =1;
    private Bitmap bitmap;
    ProgressDialog progressDialog;

    private DatabaseReference reference;
    private StorageReference storageReference;
    String downloadUrl;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_image);
        selectImage = findViewById(R.id.selectImage);
        imageCategory = findViewById(R.id.image_category);
        uploadImage = findViewById(R.id.uploadImage);
        galleryImageView = findViewById(R.id.galleryImageView);
        reference = FirebaseDatabase.getInstance().getReference().child("gallery");
        storageReference = FirebaseStorage.getInstance().getReference().child("gallery");

        progressDialog = new ProgressDialog(this);


        String[] items = new String[]{"Select Category", "Convocation","Independence Day", "Other Events"};
        imageCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));

        imageCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = imageCategory.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        selectImage.setOnClickListener(v -> openGallery());

        uploadImage.setOnClickListener(v -> {
            if(bitmap ==  null){
                Toast.makeText(UploadImage.this, "Plz Upload Image.", Toast.LENGTH_SHORT).show();
            }else if (category.equals("Select Category")){
                Toast.makeText(UploadImage.this, "Plz Select Image Category", Toast.LENGTH_SHORT).show();
            }else{
                progressDialog.setMessage("Uploading...");
                progressDialog.show();
                uploadImage();


            }


        });
    }
/*
    private void uploadImage() {
        ByteArrayOutputStream baos =new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,50,baos);
        byte[] finalimage = baos.toByteArray();
        final StorageReference filePath;
        filePath =storageReference.child(Arrays.toString(finalimage) +"jpg");
        final UploadTask uploadTask = filePath.putBytes(finalimage);
        uploadTask.addOnCompleteListener(UploadImage.this, task -> {
            if(task.isSuccessful()){
                uploadTask.addOnSuccessListener(taskSnapshot -> filePath.getDownloadUrl().addOnSuccessListener(uri -> {
                    downloadUrl = String.valueOf(uri);
                    uploadData();

                }));
            } else {
                progressDialog.dismiss();
                Toast.makeText(UploadImage.this, "Something went Wrong", Toast.LENGTH_SHORT).show();

            }

        });
    }

 */


    private void uploadImage() {
        progressDialog.setMessage("Uploading...");
        progressDialog.show();
        ByteArrayOutputStream baos =new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,50,baos);
        byte[] finalimage = baos.toByteArray();
        final StorageReference filePath;
        filePath =storageReference.child("Notice").child(finalimage+"jpg");
        final UploadTask uploadTask = filePath.putBytes(finalimage);
        uploadTask.addOnCompleteListener(UploadImage.this, task -> {
            if(task.isSuccessful()){
                uploadTask.addOnSuccessListener(taskSnapshot -> filePath.getDownloadUrl().addOnSuccessListener(uri -> {
                    downloadUrl = String.valueOf(uri);
                    uploadData();

                }));
            } else {
                progressDialog.dismiss();
                Toast.makeText(UploadImage.this, "Something went Wrong", Toast.LENGTH_SHORT).show();

            }

        });


    }

    private void uploadData() {
        reference = reference.child(category);
        final String uniqueKey = reference.push().getKey();

        assert uniqueKey != null;
        reference.child(uniqueKey).setValue(downloadUrl).addOnSuccessListener(unused -> {
            progressDialog.dismiss();
            Toast.makeText(UploadImage.this, "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();

        }).addOnFailureListener(e -> Toast.makeText(UploadImage.this, "Some thing went wrong", Toast.LENGTH_SHORT).show());


    }


    private void openGallery() {
        Intent pickImage = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickImage,REQ);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode ==REQ && resultCode == RESULT_OK){
            Uri uri = Objects.requireNonNull(data).getData() ;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            galleryImageView.setImageBitmap(bitmap);
        }
    }
}
